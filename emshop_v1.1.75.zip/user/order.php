<?php
/**
 * The productf management
 *
 * @package EMLOG
 * @link https://www.emlog.net
 */

/**
 * @var string $action
 * @var object $CACHE
 */

//require_once 'globals.php';
require_once '../init.php';

$orderModel = new Order_Model();
$Sort_Model = new Sort_Model();
$User_Model = new User_Model();
$MediaSort_Model = new MediaSort_Model();
$Template_Model = new Template_Model();

$sta_cache = $CACHE->readCache('sta');
$user_cache = $CACHE->readCache('user');
$action = Input::getStrVar('action');

// 订单列表
if (empty($action)) {
    loginAuth::checkLogin(NULL, 'user');

    require_once './api.php';

    $res = api_get_user_order(['user_id' => UID]);
    if($res['code'] == 200){
        $list = $res['data'];
    }

//    d($list);die;

    include View::getUserView('_header');
    require_once View::getUserView('order');
    include View::getUserView('_footer');
    View::output();
}
// 订单列表
if ($action == 'search') {
    $tab = 'search';
    $pwd = Input::getStrVar('pwd');
    if(empty($pwd)){
        include View::getUserView('header');
        require_once View::getUserView('order');
        include View::getUserView('footer');
        View::output();
    }
    $page = Input::getIntVar('page', 1);
    $orderNum = $orderModel->getYoukeOrderNum($pwd);
    $order = $orderModel->getYoukeOrderForHome($page, $pwd);
    $subPage = '';
    foreach ($_GET as $key => $val) {
        $subPage .= $key != 'page' ? "&$key=$val" : '';
    }
    $pageurl = pagination($orderNum, Option::get('admin_article_perpage_num'), $page, "order.php?{$subPage}&page=");
    $GLOBALS['mode_payment'] = [];
    doAction('mode_payment');
    if(isset($GLOBALS['mode_payment'][0])){
        $GLOBALS['mode_payment'][0]['active'] = true;
    }
    $mode_payment = $GLOBALS['mode_payment'];
    include View::getUserView('header');
    require_once View::getUserView('order');
    include View::getUserView('footer');
    View::output();
}

if($action == 'download'){
    $db = Database::getInstance();
    $id = Input::getIntVar('order_list_id'); // 子订单ID
    $sql = "SELECT * from " . DB_PREFIX . "deliver WHERE order_list_id={$id} order by id asc";
    $res = $db->query($sql);
    $content = "";
    while ($row = $db->fetch_array($res)) {
        $content .= $row['content'] . "\r\n";
    }
    $date = date('YmdHis');
    $filename = '卡密-' . $date . '.txt';
    // 设置HTTP头
    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($content));
    // 输出内容
    echo $content;
    exit;
}

// 订单详情页
if($action == 'sdk'){
    $db = Database::getInstance();
    $db_prefix = DB_PREFIX;
    $out_trade_no = Input::getStrVar('out_trade_no');
    $order = $db->once_fetch_array("select * from {$db_prefix}order where out_trade_no = '{$out_trade_no}'");
    $child_order = $db->once_fetch_array("select * from {$db_prefix}order_list where order_id = {$order['id']}");
    $goods = $db->once_fetch_array("select * from {$db_prefix}goods where id = {$child_order['goods_id']}");
    doAction('view_order_detail', $db, $db_prefix, $goods, $order, $child_order);
    die;
}
if($action == 'get_order_serect'){
    require_once './api.php';
    $post = [
        'out_trade_no' => Input::postStrVar('out_trade_no'),
        'limit' => Input::postIntVar('limit')
    ];
    $res =  api_get_order_serect($post);
    echo json_encode($res);die;
}

