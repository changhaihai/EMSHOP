<?php defined('EM_ROOT') || exit('access denied!'); ?>

<style>
    /* 主内容区样式 */
    .main-content {
        padding: 20px 15px;
    }

    /* 自定义卡片 */
    .custom-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 24px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        overflow: hidden;
        margin-bottom: 20px;
    }

    .custom-card-body {
        padding: 32px;
    }

    /* 用户欢迎区域 */
    .welcome-section {
        text-align: center;
        margin-bottom: 32px;
    }

    .welcome-avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 16px;
        font-size: 32px;
        color: white;
        font-weight: 700;
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
    }

    .welcome-title {
        font-size: 24px;
        font-weight: 700;
        color: #333;
        margin-bottom: 8px;
    }

    .welcome-subtitle {
        font-size: 14px;
        color: #666;
        margin-bottom: 24px;
    }

    /* 统计卡片网格 */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
        margin-bottom: 32px;
    }

    .stat-card {
        background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
        border: 1px solid rgba(102, 126, 234, 0.2);
        border-radius: 16px;
        padding: 20px;
        text-align: center;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
        border-color: #667eea;
    }

    .stat-icon {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 12px;
        font-size: 20px;
        color: white;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.2);
    }

    .stat-value {
        font-size: 24px;
        font-weight: 700;
        color: #333;
        margin-bottom: 4px;
    }

    .stat-label {
        font-size: 12px;
        color: #666;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* 信息框 */
    .info-box {
        background: linear-gradient(135deg, rgba(168, 85, 247, 0.05) 0%, rgba(102, 126, 234, 0.05) 100%);
        border: 1px solid rgba(168, 85, 247, 0.2);
        border-radius: 16px;
        padding: 24px;
    }

    .info-title {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 16px;
        font-weight: 600;
        color: #333;
        margin-bottom: 20px;
    }

    .info-grid {
        display: grid;
        gap: 16px;
    }

    .info-item {
        display: flex;
        align-items: center;
        padding: 16px;
        background: rgba(255, 255, 255, 0.7);
        border-radius: 12px;
        border: 1px solid rgba(102, 126, 234, 0.1);
        transition: all 0.3s ease;
    }

    .info-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
        background: rgba(255, 255, 255, 0.9);
    }

    .info-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 16px;
        font-size: 18px;
        color: white;
        flex-shrink: 0;
    }

    .info-content {
        flex: 1;
    }

    .info-label {
        font-size: 12px;
        color: #666;
        margin-bottom: 4px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .info-value {
        font-size: 16px;
        font-weight: 600;
        color: #333;
    }

    .info-value.empty {
        color: #999;
        font-style: italic;
    }

    /* 快捷操作按钮 */
    .quick-actions {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 12px;
        margin-top: 24px;
    }

    .action-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 12px 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 12px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.2);
    }

    .action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3);
        text-decoration: none;
        color: white;
    }

    .action-btn i {
        font-size: 16px;
    }

    /* 响应式优化 */
    @media (max-width: 768px) {
        .main-content {
            padding: 15px 10px;
        }
        
        .custom-card-body {
            padding: 24px 20px;
        }
        
        .welcome-avatar {
            width: 64px;
            height: 64px;
            font-size: 24px;
        }
        
        .welcome-title {
            font-size: 20px;
        }
        
        .stats-grid {
            grid-template-columns: 1fr;
            gap: 12px;
        }
        
        .info-grid {
            gap: 12px;
        }
        
        .info-item {
            padding: 12px;
        }
        
        .info-icon {
            width: 36px;
            height: 36px;
            font-size: 16px;
            margin-right: 12px;
        }
        
        .quick-actions {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 480px) {
        .welcome-avatar {
            width: 56px;
            height: 56px;
            font-size: 20px;
        }
        
        .welcome-title {
            font-size: 18px;
        }
        
        .stat-value {
            font-size: 20px;
        }
        
        .info-item {
            flex-direction: column;
            text-align: center;
            padding: 16px 12px;
        }
        
        .info-icon {
            margin-right: 0;
            margin-bottom: 8px;
        }
        
        .action-btn {
            padding: 10px 16px;
            font-size: 13px;
        }
    }
</style>

<main class="main-content">

    <div class="custom-card">
        <div class="custom-card-body">
            <!-- 欢迎区域 -->
            <div class="welcome-section">
                <div class="welcome-avatar">
                    <?= substr($userData['username'], 0, 1) ?>
                </div>
                <h1 class="welcome-title">欢迎回来，<?= $userData['username'] ?></h1>
                <p class="welcome-subtitle">管理您的账户信息和设置</p>
            </div>

            <!-- 统计数据 -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fa fa-wallet"></i>
                    </div>
                    <div class="stat-value">¥<?= number_format($userData['money'], 2) ?></div>
                    <div class="stat-label">账户余额</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fa fa-shopping-cart"></i>
                    </div>
                    <div class="stat-value">¥<?= number_format($userData['expend'], 2) ?></div>
                    <div class="stat-label">总消费额</div>
                </div>
            </div>

            <!-- 详细信息 -->
            <div class="info-box">
                <div class="info-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#a855f7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-check" aria-hidden="true">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="m9 12 2 2 4-4"></path>
                    </svg>
                    <span>账户信息</span>
                </div>
                <div class="grid-gap-12 grid-cols-md-2">
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fa fa-user"></i>
                        </div>
                        <div class="info-content">
                            <div class="info-label">商户ID</div>
                            <div class="info-value"><?= UID ?></div>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fa fa-user"></i>
                        </div>
                        <div class="info-content">
                            <div class="info-label">商户密钥</div>
                            <div class="info-value"><?= $token ?></div>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="info-content">
                            <div class="info-label">登录手机</div>
                            <div class="info-value <?= empty($userData['tel']) ? 'empty' : '' ?>">
                                <?= empty($userData['tel']) ? '未绑定手机' : $userData['tel'] ?>
                            </div>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <div class="info-content">
                            <div class="info-label">登录邮箱</div>
                            <div class="info-value <?= empty($userData['email']) ? 'empty' : '' ?>">
                                <?= empty($userData['email']) ? '未绑定邮箱' : $userData['email'] ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 快捷操作 -->
                <!-- <div class="quick-actions">
                    <a href="?route=profile" class="action-btn">
                        <i class="fa fa-edit"></i>
                        编辑资料
                    </a>
                    <a href="?route=change_password" class="action-btn">
                        <i class="fa fa-lock"></i>
                        修改密码
                    </a>
                    <a href="?route=order" class="action-btn">
                        <i class="fa fa-list"></i>
                        订单记录
                    </a>
                </div> -->
            </div>
        </div>
    </div>
</main>

<script>
    $('#menu-index').addClass('open menu-current');
</script>