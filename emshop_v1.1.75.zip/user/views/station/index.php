<?php
defined('EM_ROOT') || exit('access denied!');
?>
<style>
    /* 主内容区样式 */
    .main-content {
        padding: 20px 15px;
    }

    /* 自定义卡片 */
    .custom-card-body {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 24px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        padding: 32px;
        overflow: hidden;
    }

    /* 统计卡片样式 */
    .plan-item {
        background: #fff;
        border-radius: 16px;
        padding: 24px;
        text-align: center;
        position: relative;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        border: 2px solid transparent;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        overflow: hidden;
    }

    .plan-item::before {
        content: "";
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(102, 126, 234, 0.1), transparent);
        transition: left 0.6s ease;
    }

    .plan-item:hover::before {
        left: 100%;
    }

    .plan-item:hover {
        transform: translateY(-8px);
        box-shadow: 0 12px 40px rgba(102, 126, 234, 0.2);
        border-color: #667eea;
    }

    /* 套餐标题 */
    .plan-title {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        font-size: 18px;
        font-weight: 700;
        color: #333;
        margin-bottom: 16px;
    }

    .plan-title svg {
        width: 24px;
        height: 24px;
        color: #667eea;
    }

    /* 套餐价格 */
    .plan-price {
        font-size: 24px;
        font-weight: 800;
        color: #667eea;
        margin-bottom: 24px;
        line-height: 1;
    }

    .plan-price small {
        font-size: 12px;
        color: #999;
        font-weight: 400;
    }

    /* 功能列表 */
    .feature-list {
        list-style: none;
        padding: 0;
        margin: 0;
        text-align: left;
    }

    .feature-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 0;
        border-bottom: 1px solid #f3f4f6;
        font-size: 14px;
        color: #374151;
    }

    .feature-item:last-child {
        border-bottom: none;
    }

    .feature-value {
        font-weight: 600;
        color: #667eea;
        background: rgba(102, 126, 234, 0.1);
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 12px;
    }

    /* 信息框 */
    .info-box {
        background: linear-gradient(135deg, rgba(168, 85, 247, 0.05) 0%, rgba(102, 126, 234, 0.05) 100%);
        border: 1px solid rgba(168, 85, 247, 0.2);
        border-radius: 16px;
        padding: 24px;
        margin-top: 30px;
    }

    .info-title {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 16px;
        font-weight: 600;
        color: #333;
        margin-bottom: 20px;
    }

    .info-title-text {
        font-size: 16px;
        font-weight: 600;
        color: #333;
    }

    .info-details {
        display: grid;
        gap: 16px;
    }

    .info-details p {
        display: flex;
        align-items: center;
        padding: 16px;
        background: rgba(255, 255, 255, 0.7);
        border-radius: 12px;
        border: 1px solid rgba(102, 126, 234, 0.1);
        transition: all 0.3s ease;
        margin: 0;
    }

    .info-details p:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
        background: rgba(255, 255, 255, 0.9);
    }

    .info-label {
        font-size: 14px;
        color: #666;
        font-weight: 500;
        margin-right: 12px;
        min-width: 80px;
    }

    .info-value {
        font-size: 14px;
        font-weight: 600;
        color: #333;
        flex: 1;
    }

    .domain-a {
        color: #667eea;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .domain-a:hover {
        color: #764ba2;
        text-decoration: none;
        transform: translateY(-1px);
    }

    .unconfigured {
        color: #ef4444;
        font-style: italic;
        font-weight: 500;
        background: rgba(239, 68, 68, 0.1);
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 12px;
    }

    /* 响应式优化 */
    @media (max-width: 768px) {
        .main-content {
            padding: 15px 10px;
        }
        
        .custom-card-body {
            padding: 24px 20px;
        }
        
        .plan-item {
            padding: 20px 16px;
        }
        
        .plan-title {
            font-size: 16px;
        }
        
        .plan-price {
            font-size: 20px;
        }
        
        .info-box {
            padding: 20px 16px;
        }
        
        .info-details p {
            flex-direction: column;
            align-items: flex-start;
            padding: 12px;
        }
        
        .info-label {
            margin-right: 0;
            margin-bottom: 4px;
            min-width: auto;
        }
    }

    @media (max-width: 480px) {
        .custom-card-body {
            padding: 20px 16px;
        }
        
        .plan-item {
            padding: 16px 12px;
        }
        
        .plan-title {
            font-size: 14px;
            gap: 6px;
        }
        
        .plan-price {
            font-size: 18px;
            margin-bottom: 20px;
        }
        
        .feature-item {
            padding: 10px 0;
            font-size: 13px;
        }
        
        .info-box {
            padding: 16px 12px;
        }
        
        .info-details p {
            padding: 10px;
        }
    }
</style>

<!-- 主内容区 -->
<main class="main-content">
    <div class="custom-card-body">
        <div class="grid-gap-10 grid-cols-xs-2 grid-cols-sm-2 grid-cols-md-3 grid-cols-xl-4" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
            <div class="plan-item">
                <div class="plan-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-crown icon-crown crown-bronze" aria-hidden="true">
                        <path d="M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z"></path>
                        <path d="M5 21h14"></path>
                    </svg>
                    我的店铺
                </div>
                <div class="plan-price"><?= htmlspecialchars($station['name']) ?> <small>/ &nbsp;已开通</small></div>
                <ul class="feature-list">
                    <li class="feature-item">
                        <span>&nbsp;</span>
                        <span class="feature-value">&nbsp;</span>
                    </li>
                    <li class="feature-item">
                        <span>&nbsp;</span>
                        <span class="feature-value">&nbsp;</span>
                    </li>
                    <li class="feature-item">
                        <span>开通日期</span>
                        <span class="feature-value"><?= date('Y-m-d', $station['create_time']) ?></span>
                    </li>
                </ul>
            </div>
            
            <div class="plan-item">
                <div class="plan-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users" aria-hidden="true">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                    注册用户
                </div>
                <div class="plan-price"><?= $today_users ?> <small>/ &nbsp;今日注册</small></div>
                <ul class="feature-list">
                    <li class="feature-item">
                        <span>昨日</span>
                        <span class="feature-value"><?= $yesterday_users ?></span>
                    </li>
                    <li class="feature-item">
                        <span>本月</span>
                        <span class="feature-value"><?= $month_users ?></span>
                    </li>
                    <li class="feature-item">
                        <span>全部</span>
                        <span class="feature-value"><?= $total_users ?></span>
                    </li>
                </ul>
            </div>
            
            <div class="plan-item">
                <div class="plan-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-cart" aria-hidden="true">
                        <circle cx="8" cy="21" r="1"></circle>
                        <circle cx="19" cy="21" r="1"></circle>
                        <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"></path>
                    </svg>
                    订单数量
                </div>
                <div class="plan-price"><?= $today_orders ?> <small>/ &nbsp;今日订单数</small></div>
                <ul class="feature-list">
                    <li class="feature-item">
                        <span>昨日</span>
                        <span class="feature-value"><?= $yesterday_orders ?></span>
                    </li>
                    <li class="feature-item">
                        <span>本月</span>
                        <span class="feature-value"><?= $month_orders ?></span>
                    </li>
                    <li class="feature-item">
                        <span>全部</span>
                        <span class="feature-value"><?= $total_orders ?></span>
                    </li>
                </ul>
            </div>
            
            <div class="plan-item">
                <div class="plan-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-wallet" aria-hidden="true">
                        <path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"></path>
                        <path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"></path>
                    </svg>
                    订单金额
                </div>
                <div class="plan-price"><?= $today_amount ?> <small>/ &nbsp;今日订单额</small></div>
                <ul class="feature-list">
                    <li class="feature-item">
                        <span>昨日</span>
                        <span class="feature-value"><?= $yesterday_amount ?></span>
                    </li>
                    <li class="feature-item">
                        <span>本月</span>
                        <span class="feature-value"><?= $month_amount ?></span>
                    </li>
                    <li class="feature-item">
                        <span>全部</span>
                        <span class="feature-value"><?= $total_amount ?></span>
                    </li>
                </ul>
            </div>
        </div>

        <div class="grid-gap-10 grid-cols-xs-1 grid-cols-sm-1 grid-cols-md-1 grid-cols-xl-1" style="margin-top: 30px;">
            <div class="info-box">
                <div class="info-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#a855f7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-check" aria-hidden="true">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="m9 12 2 2 4-4"></path>
                    </svg>
                    <span class="info-title-text">店铺信息【<?= htmlspecialchars($station['name']) ?>】</span>
                </div>
                
                <div class="info-details">
                    <p>
                        <span class="info-label">• 独立域名：</span>
                        <span class="info-value">
                            <?php if(empty($userData['station']['domain'])): ?>
                                <span class="unconfigured">未配置</span>
                            <?php else: ?>
                                <a href="//<?= htmlspecialchars($userData['station']['domain']) ?>" class="domain-a" target="_blank">
                                    <?= htmlspecialchars($userData['station']['domain']) ?>
                                </a>
                            <?php endif; ?>
                        </span>
                    </p>
                    
                    <p>
                        <span class="info-label">• 二级域名：</span>
                        <span class="info-value">
                            <?php if(empty($userData['station']['domain_2'])): ?>
                                <span class="unconfigured">未配置</span>
                            <?php else: ?>
                                <a href="//<?= htmlspecialchars($userData['station']['domain_2']) ?>" class="domain-a" target="_blank">
                                    <?= htmlspecialchars($userData['station']['domain_2']) ?>
                                </a>
                            <?php endif; ?>
                        </span>
                    </p>
                    
                    <p>
                        <span class="info-label">• 店铺名称：</span>
                        <span class="info-value">
                            <?php if(empty($userData['station']['name'])): ?>
                                <span class="unconfigured">未配置</span>
                            <?php else: ?>
                                <?= htmlspecialchars($userData['station']['name']) ?>
                            <?php endif; ?>
                        </span>
                    </p>
                    
                    <p>
                        <span class="info-label">• 网站标题：</span>
                        <span class="info-value">
                            <?php if(empty($userData['station']['title'])): ?>
                                <span class="unconfigured">未配置</span>
                            <?php else: ?>
                                <?= htmlspecialchars($userData['station']['title']) ?>
                            <?php endif; ?>
                        </span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    $('#menu-station').addClass('open');
    $('#menu-station > ul').css('display', 'block');
    $('#menu-station > a > i.nav_right').attr('class', 'fa fa-angle-down nav_right');
    $('#menu-station-index').addClass('menu-current');
</script>