<?php
defined('EM_ROOT') || exit('access denied!');
?>
<style>
    /* 主内容区样式 */
    .main-content {
        padding: 20px 15px;
    }

    /* 自定义面板 */
    .main-content .layui-panel {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 24px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        padding: 32px;
        overflow: hidden;
    }

    

    /* 表单样式优化 */
    .layui-form {
        max-width: 800px;
        margin: 0 auto;
    }

    .layui-form-item {
        margin-bottom: 24px;
        background: rgba(255, 255, 255, 0.7);
        border-radius: 16px;
        padding: 20px;
        border: 1px solid rgba(102, 126, 234, 0.1);
        transition: all 0.3s ease;
    }

    .layui-form-item:hover {
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
        background: rgba(255, 255, 255, 0.9);
    }

    .layui-form-label {
        color: #667eea;
        font-weight: 600;
        font-size: 14px;
        margin-bottom: 8px;
        display: block;
    }

    .layui-input-block {
        position: relative;
    }

    .layui-input {
        border: 2px solid #e5e7eb;
        border-radius: 12px;
        padding: 12px 16px;
        font-size: 14px;
        transition: all 0.3s ease;
        background: rgba(255, 255, 255, 0.8);
    }

    .layui-input:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        background: white;
    }

    .layui-textarea {
        border: 2px solid #e5e7eb;
        border-radius: 12px;
        padding: 12px 16px;
        font-size: 14px;
        transition: all 0.3s ease;
        background: rgba(255, 255, 255, 0.8);
        resize: vertical;
        min-height: 100px;
    }

    .layui-textarea:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        background: white;
    }

    /* 单选按钮样式 */
    .layui-form-radio {
        margin-right: 20px;
        margin-bottom: 8px;
    }

    .layui-form-radio i {
        font-size: 16px;
        color: #667eea;
    }

    .layui-form-radioed i {
        color: #667eea;
    }

    /* 下拉选择框 */
    .layui-form-select {
        border-radius: 12px;
        border: 2px solid #e5e7eb;
        background: rgba(255, 255, 255, 0.8);
    }

    .layui-form-select dl {
        border-radius: 12px;
        border: 2px solid #e5e7eb;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    /* 内联表单项 */
    .layui-inline {
        display: flex;
        gap: 12px;
        align-items: center;
        margin-bottom: 16px;
    }

    .layui-input-inline {
        flex: 1;
    }

    /* 表单提示 */
    .form-tips {
        display: block;
        margin-top: 8px;
        font-size: 12px;
        color: #666;
        background: rgba(102, 126, 234, 0.05);
        padding: 8px 12px;
        border-radius: 8px;
    }

    /* 提交按钮 */
    .btn-submit {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        padding: 16px 48px;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        position: relative;
        overflow: hidden;
    }

    .btn-submit::before {
        content: "";
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left 0.6s ease;
    }

    .btn-submit:hover::before {
        left: 100%;
    }

    .btn-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 35px rgba(102, 126, 234, 0.4);
    }

    .btn-submit:active {
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3);
    }

    /* TinyMCE编辑器样式 */
    .tox-tinymce {
        border-radius: 12px !important;
        border: 2px solid #e5e7eb !important;
        overflow: hidden;
    }

    .tox-toolbar__group {
        background: rgba(255, 255, 255, 0.9);
    }

    .tox-edit-area__iframe {
        background: white !important;
    }

    /* 响应式优化 */
    @media (max-width: 768px) {
        .main-content {
            padding: 15px 10px;
        }
        
        .main-content .layui-panel {
            padding: 24px 20px;
        }
        
        .layui-form {
            max-width: 100%;
        }
        
        .layui-form-item {
            padding: 16px;
            margin-bottom: 20px;
        }
        
        .layui-tabs-header {
            flex-direction: column;
            gap: 8px;
        }
        
        .layui-tabs-header li a {
            padding: 10px 16px;
            font-size: 13px;
        }
        
        .layui-inline {
            flex-direction: column;
            align-items: stretch;
        }
        
        .btn-submit {
            width: 100%;
            padding: 14px 24px;
        }
    }

    @media (max-width: 480px) {
        .main-content .layui-panel {
            padding: 20px 16px;
        }
        
        .layui-form-item {
            padding: 12px;
        }
        
        .layui-input, .layui-textarea {
            padding: 10px 12px;
            font-size: 13px;
        }
        
        .layui-tabs-header li a {
            padding: 8px 12px;
            font-size: 12px;
        }
        
        .btn-submit {
            padding: 12px 20px;
            font-size: 14px;
        }
    }
</style>

<!-- 主内容区 -->
<main class="main-content">



    <div class="layui-panel">

        <div class="layui-tabs" style="margin-bottom: 22px;" lay-options="{trigger: false}" lay-tabs-id="1">
            <ul class="layui-tabs-header">
                <li class="layui-this"><a href="?action=setting">基础设置</a></li>
                <li><a href="?action=setting_tpl">模板配置</a></li>
            </ul>
        </div>

        <form class="layui-form" action="">
            <div class="layui-form-item">
                <label class="layui-form-label">店铺名称</label>
                <div class="layui-input-block">
                    <input type="text" name="name" value="<?= $userStation['name'] ?>" placeholder="请输入店铺名称" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">网站标题</label>
                <div class="layui-input-block">
                    <input type="text" name="title" value="<?= $userStation['title'] ?>" placeholder="请输入网站标题" class="layui-input">
                </div>
                <span class="form-tips">显示在网页浏览器上的标题</span>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">主站分类</label>
                <div class="layui-input-block">
                    <input type="radio" name="master_sort" <?= $userStation['master_sort'] == 1 ? 'checked' : '' ?> value="1" title="全部显示" >
                    <input type="radio" name="master_sort" <?= $userStation['master_sort'] == 2 ? 'checked' : '' ?> value="2" title="全部隐藏">
                    <input type="radio" name="master_sort" <?= $userStation['master_sort'] == 3 ? 'checked' : '' ?> value="3" title="自定义（在主站分类菜单中配置）">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">主站商品</label>
                <div class="layui-input-block">
                    <input type="radio" name="master_goods" <?= $userStation['master_goods'] == 1 ? 'checked' : '' ?> value="1" title="全部显示">
                    <input type="radio" name="master_goods" <?= $userStation['master_goods'] == 2 ? 'checked' : '' ?> value="2" title="全部隐藏">
                    <input type="radio" name="master_goods" <?= $userStation['master_goods'] == 3 ? 'checked' : '' ?> value="3" title="自定义（在主站商品菜单中配置）">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <label class="layui-form-label">二级域名</label>
                    <div class="layui-input-inline">
                        <input type="text" value="<?= $userStation['domain_2_prefix'] ?>" name="domain_2_prefix" placeholder="域名前缀" class="layui-input">
                    </div>
                </div>
                <div class="layui-inline">
                    <div class="layui-input-inline">
                        <label class="layui-form-label">&nbsp;</label>
                        <select name="domain_2_suffix">
                            <?php foreach($station_domain as $val): ?>
                            <option value=".<?= $val; ?>" <?= $userStation['domain_2_suffix'] == '.' . $val ? 'selected' : '' ?>>.<?= $val; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">独立域名</label>
                <div class="layui-input-block">
                    <input type="text" name="domain" value="<?= $userStation['domain'] ?>" placeholder="请输入您的域名" class="layui-input">
                    <span class="form-tips">cname解析域名：<?= Option::get('station_cname_domain') ?></span>
                </div>
            </div>
            <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">滚动公告</label>
                <div class="layui-input-block">
                    <textarea placeholder="请输入内容" name="roll_notice" class="layui-textarea"><?= $userStation['roll_notice'] ?></textarea>
                </div>
            </div>
            <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">内容公告</label>
                <div class="layui-input-block">
                    <textarea placeholder="请输入内容" id="home_notice" name="home_notice" class="layui-textarea"><?= $userStation['home_notice'] ?></textarea>
                </div>
            </div>



            <div class="layui-form-item">
                <div class="layui-input-block" style="text-align: left;">
                    <button class="btn-submit" lay-submit lay-filter="submit">保存信息</button>
                </div>
            </div>
        </form>
    </div>


</main>

<script src="<?= EM_URL ?>admin/tinymce/tinymce.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
<script>
    // 初始化Layui模块
    layui.use(['element', 'layer'], function() {
        var element = layui.element;
        var layer = layui.layer;
        var form = layui.form;

        form.on('submit(submit)', function(data){
            var field = data.field; // 获取表单全部字段值
            $.ajax({
                type: "POST",
                url: "?action=setting_ajax",
                data: field,
                dataType: "json",
                success: function (e) {
                    if(e.code == 400){
                        layer.msg(e.msg)
                    }else{
                        layer.msg(e.msg)
                    }

                },
                error: function (xhr) {
                    layer.msg('网络请求发生错误，请重试')
                },
                complete: function(){

                }
            });
            return false; // 阻止默认 form 跳转
        });

        const example_image_upload_handler = (blobInfo, progress) => new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.withCredentials = false;
            xhr.open('POST', '/admin/article.php?action=upload_cover2');
            xhr.upload.onprogress = (e) => {
                progress(e.loaded / e.total * 100);
            };
            xhr.onload = () => {
                if (xhr.status === 403) {
                    reject({ message: 'HTTP Error: ' + xhr.status, remove: true });
                    return;
                }
                if (xhr.status < 200 || xhr.status >= 300) {
                    reject('HTTP Error: ' + xhr.status);
                    return;
                }
                const json = JSON.parse(xhr.responseText);
                if (!json || typeof json.location != 'string') {
                    reject('Invalid JSON: ' + xhr.responseText);
                    return;
                }
                resolve(json.location);
            };
            xhr.onerror = () => {
                reject('Image upload failed due to a XHR Transport error. Code: ' + xhr.status);
            };
            const formData = new FormData();
            formData.append('image', blobInfo.blob(), blobInfo.filename());
            xhr.send(formData);
        });
        tinymce.init({
            selector: 'textarea#home_notice',
            language: 'zh_CN',
            height: 300,
            images_upload_handler: example_image_upload_handler,
            plugins: [
                'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
                'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
                'insertdatetime', 'media', 'table', 'wordcount', 'autosave'
            ],
            autosave_ask_before_unload: false,
            toolbar: 'undo redo | blocks | ' +
                'bold italic backcolor | alignleft aligncenter ' +
                'alignright alignjustify | bullist numlist outdent indent | ' +
                'removeformat',
            content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }',



            // 添加初始化完成后的回调
            setup: function(editor) {
                editor.on('init', function() {
                    // 保存编辑器实例到全局变量
                    editorInstance = editor;
                    console.log('TinyMCE 初始化完成');
                });
                editor.on('input change undo redo cut paste', function() {
                    // 手动更新关联的文本域
                    editor.save();
                });
            }
        }).then(function(editors) {
            // 可选：Promise 方式获取编辑器实例
            if (editors && editors.length > 0) {
                editorInstance = editors[0];
            }
        }).catch(function(error) {
            console.error('TinyMCE 初始化失败:', error);
        });

    });
</script>

<script>
    $('#menu-station').addClass('open');
    $('#menu-station > ul').css('display', 'block');
    $('#menu-station > a > i.nav_right').attr('class', 'fa fa-angle-down nav_right');
    $('#menu-station-setting').addClass('menu-current');
</script>
