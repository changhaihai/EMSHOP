<?php



require_once '../init.php';

$action = Input::getStrVar('action');

if (empty($action)) {
    $order_required = Option::get('order_required');
    $order_required = empty($order_required) ? [] : json_decode($order_required, true);
    include View::getUserView('_header');
    require_once(View::getUserView('visitors'));
    include View::getUserView('_footer');
    View::output();
}

if($action == 'get_visitors_order'){
    require_once './api.php';

    $_search = Input::getStrVar('_search');
    $_search = json_decode(base64_decode($_search), true);

//    d($_search);die;

    $res = api_get_visitors_order($_search);
    if($res['code'] == 200){
        $list = $res['data'];
    }

//    d($list);die;

    include View::getUserView('_header');
    require_once(View::getUserView('visitors_order'));
    include View::getUserView('_footer');
    View::output();
}

if($action == 'visitors_search_order_count'){
    require_once './api.php';
    $res =  api_visitors_search_order_count();

    echo json_encode($res);die;
}

if($action == 'sdk'){
    $db = Database::getInstance();
    $db_prefix = DB_PREFIX;
    $out_trade_no = Input::getStrVar('out_trade_no');
    $order = $db->once_fetch_array("select * from {$db_prefix}order where out_trade_no = '{$out_trade_no}'");
    $child_order = $db->once_fetch_array("select * from {$db_prefix}order_list where order_id = {$order['id']}");
    $goods = $db->once_fetch_array("select * from {$db_prefix}goods where id = {$child_order['goods_id']}");
    doAction('view_order_detail', $db, $db_prefix, $goods, $order, $child_order);
    die;
}
