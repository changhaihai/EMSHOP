<?php
/*@support tpl_options*/

/**
 * 模板设置的配置文件
 */

defined('EM_ROOT') || exit('access denied!');

$options = [
    'TplOptionsNavi' => [
        'type'        => 'radio',
        'name'        => '定义设置项标签页名称',
        'values'      => [
//            'tpl-head' => '头部设置',
            'tpl-basic' => '基础配置',
        ],
        'description' => '<p>你好，这是本模板的设置界面，请点击菜单进入设置项。</p>'
    ],

    'favicon'        => [
        'labels'      => 'tpl-basic',
        'type'        => 'image',
        'name'        => '浏览器图标（favicon）',
        'values'      => [
            TEMPLATE_URL . 'images/favicon.png',
        ],
        'description' => '上传浏览器图标，推荐尺寸48×48的PNG或JPG图片'
    ],
    'category_show'       => [
        'labels'      => 'tpl-basic',
        'type'        => 'checkon',
        'name'        => '■ 显示分类模块',
        'values'      => ['1' => '显示'],
        'default'     => '1',
        'description' => '关闭则隐藏分类模块'
    ],
];