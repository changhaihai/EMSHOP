<?php
/**
 * 页面底部信息
 */
defined('EM_ROOT') || exit('access denied!');
?>


<footer class="main-footer" style="margin-top: 20px;">
    <div class="container">
        <div class="footer-content">
            <div class="footer-info">
                <div class="copyright">
                    <span><?= $footer_info ?></span>
                    <?php if (!empty($icp)): ?>
                        <span class="divider">|</span>
                        <a href="https://beian.miit.gov.cn/" target="_blank"><?= $icp ?></a>
                    <?php endif; ?>
                    <span class="divider">|</span>
                    <?php doAction('index_footer') ?>
                </div>
            </div>
        </div>
    </div>
</footer>

<style>
    /* 桌面端页脚样式 - 极简版 */
    .main-footer {
        background: #fff;
        padding: 20px 0;
        color: #999;
        border-top: 1px solid #eee;
        font-size: 12px;
    }
    
    .footer-content {
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
    }

    .footer-brand-text {
        font-weight: 700;
        color: #4C7D71;
        font-size: 13px;
    }

    .copyright {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        gap: 5px;
    }

    .copyright a {
        color: #999;
        transition: color 0.2s;
    }
    
    .copyright a:hover {
        color: #4C7D71;
        text-decoration: none;
    }

    .divider {
        color: #eee;
        margin: 0 2px;
        font-size: 10px;
    }

    /* 移动端适配 */
    @media (max-width: 768px) {
        .copyright {
            flex-direction: column;
            gap: 2px;
        }
        .divider {
            display: none; /* 移动端隐藏竖线，改换行 */
        }
    }
</style>

<!-- 底部导航 -->
<footer class="footer-nav tel-footer">
    <a href="<?= EM_URL ?>" class="nav-item active">
        <i class="fa fa-home nav-icon"></i>
        <span>首页</span>
    </a>
    <a href="/user/visitors.php" class="nav-item">
        <i class="fa fa-search nav-icon"></i>
        <span>游客查单</span>
    </a>
    <?php if(Option::get('login_switch') == 'y' && Option::get('register_switch') == 'y'): ?>
    <a href="/user/balance.php" class="nav-item">
        <i class="fa fa-user nav-icon"></i>
        <span>个人中心</span>
    </a>
    <?php endif; ?>
</footer>




<script>
    let tipsMsg = {
        least_one    : '',
        exceeds      : '',
        exceeds_limit: '',
        mobile_order : ''
    };
</script>
<?php doAction('page_footer') ?>
</body>
</html>