<?php
/**
 * @package EMSHOP
 */

class Goods_Model {

    private $db;
    private $Parsedown;
    private $table;
    private $table_user;
    private $table_sort;
    private $table_station_goods;
    private $table_station_sort;
    private $table_skus;
    private $table_discount;
    private $table_member_price;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->table = DB_PREFIX . 'goods';
        $this->table_user = DB_PREFIX . 'user';
        $this->table_sort = DB_PREFIX . 'sort';
        $this->table_skus = DB_PREFIX . 'skus';
        $this->table_discount = DB_PREFIX . 'discount';
        $this->table_station_sort = DB_PREFIX . 'station_sort';
        $this->table_station_goods = DB_PREFIX . 'station_goods';
        $this->table_member_price = DB_PREFIX . 'member_price';
        $this->Parsedown = new Parsedown();
        $this->Parsedown->setBreaksEnabled(true); //automatic line wrapping
    }

    /**
     * 添加商品
     * 步骤：
     *  1. 写入商品主表
     *  2. 写入批量优惠表
     *  3. 写入会员价格表
     *  4. 写入商品规格表
     */
    public function addGoods($post){
        $this->db->beginTransaction();
        try{
            // 写入商品主表
            $goods_insert = [
                'title' => $post['title'],
                'sort_id' => $post['sort_id'],
                'type' => $post['type'],
                'is_sku' => $post['is_sku'],
                'attr_id' => $post['attr_id'],
                'attach_user' => json_encode($post['attach_user'], JSON_UNESCAPED_UNICODE),
                'content' => $post['content'],
                'pay_content' => $post['pay_content'],
                'cover' => $post['cover'],
                'is_on_shelf' => $post['is_on_shelf'],
                'index_top' => $post['index_top'],
                'sort_top' => $post['sort_top'],
                'sort_num' => $post['sort_num'],
                'des' => $post['des'],
                'create_time' => time()
            ];
            // d($goods_insert);die;
            $goods_id = $this->db->add('goods', $goods_insert);
            // 写入批量优惠表
            foreach($post['discount']['number'] as $key => $val){
                if(empty($val) || empty($post['discount']['amount'][$key])){
                    continue;
                }
                $discount_insert = [
                    'goods_id' => $goods_id,
                    'quantity' => $val,
                    'amount' => $post['discount']['amount'][$key] * 100,
                ];
                $this->db->add('discount', $discount_insert);
            }
            // d($post);die;
            if($post['is_sku'] == 'n'){
                // 写入会员价格表
                foreach($post['skus']['member'] as $key => $val){
                    $member_price_insert = [
                        'goods_id' => $goods_id,
                        'sku' => 0,
                        'member_level' => $key,
                        'price' => $val * 100,
                    ];
                    $this->db->add('member_price', $member_price_insert);
                }
                // 写入商品规格表
                $skus_insert = [
                    'goods_id' => $goods_id,
                    'sku' => 0,
                    'guest_price' => $post['skus']['guest_price'] * 100,
                    'user_price' => $post['skus']['user_price'] * 100,
                    'market_price' => $post['skus']['market_price'] * 100,
                    'cost_price' => $post['skus']['cost_price'] * 100,
                    'sales' => $post['skus']['sales'],
                ];
                $this->db->add('skus', $skus_insert);
            }
            
            if($post['is_sku'] == 'y'){
                // 写入会员价格表
                foreach($post['skus'] as $key => $val){
                    foreach($val['member'] as $k => $v){
                        $member_price_insert = [
                            'goods_id' => $goods_id,
                            'sku' => $key,
                            'member_level' => $k,
                            'price' => $v * 100,
                        ];
                        $this->db->add('member_price', $member_price_insert);
                    }
                }
                // 写入商品规格表
                foreach($post['skus'] as $key => $val){
                    $skus_insert = [
                        'goods_id' => $goods_id,
                        'sku' => $key,
                        'guest_price' => $val['guest_price'] * 100,
                        'user_price' => $val['user_price'] * 100,
                        'market_price' => $val['market_price'] * 100,
                        'cost_price' => $val['cost_price'] * 100,
                        'sales' => $val['sales'],
                    ];
                    $this->db->add('skus', $skus_insert);
                }
            }
            $this->db->commit();
        }catch(Throwable $e){
            $this->db->rollBack();
        }
        return $goods_id;
    }

    /**
     * 编辑商品
     * 步骤：
     *  1. 更新商品主表
     *  2. 重新写入批量优惠表
     *  3. 重新写入会员价格表
     *  4. 重新写入商品规格表
     */
    public function editGoods($goods_id, $post){
        $this->db->beginTransaction();
        try{
            // 写入商品主表
            $goods_update = [
                'title' => $post['title'],
                'sort_id' => $post['sort_id'],
                'type' => $post['type'],
                'is_sku' => $post['is_sku'],
                'attr_id' => $post['attr_id'],
                'attach_user' => json_encode($post['attach_user'], JSON_UNESCAPED_UNICODE),
                'content' => $post['content'],
                'pay_content' => $post['pay_content'],
                'cover' => $post['cover'],
                'is_on_shelf' => $post['is_on_shelf'],
                'index_top' => $post['index_top'],
                'sort_top' => $post['sort_top'],
                'sort_num' => $post['sort_num'],
                'des' => $post['des'],
            ];
            $this->db->update('goods', $goods_update, ['id' => $goods_id]);
            // 重新写入批量优惠表
            $this->db->query("DELETE FROM `{$this->table_discount}` WHERE `goods_id` = {$goods_id}");
            foreach($post['discount']['number'] as $key => $val){
                if(empty($val) || empty($post['discount']['amount'][$key])){
                    continue;
                }
                $discount_insert = [
                    'goods_id' => $goods_id,
                    'quantity' => $val,
                    'amount' => $post['discount']['amount'][$key] * 100,
                ];
                $this->db->add('discount', $discount_insert);
            }
            $this->db->query("DELETE FROM `{$this->table_member_price}` WHERE `goods_id` = {$goods_id}");
            $old_skus = $this->db->fetch_all("SELECT * FROM `{$this->table_skus}` WHERE `goods_id` = {$goods_id}");
            $this->db->query("DELETE FROM `{$this->table_skus}` WHERE `goods_id` = {$goods_id}");
            if($post['is_sku'] == 'n'){
                // 重新写入会员价格表
                foreach($post['skus']['member'] as $key => $val){
                    
                    $member_price_insert = [
                        'goods_id' => $goods_id,
                        'sku' => 0,
                        'member_level' => $key,
                        'price' => $val * 100
                    ];
                    $this->db->add('member_price', $member_price_insert);
                }
                // 重新写入商品规格表
                $stock = 0;
                foreach($old_skus as $v){
                    if($v['sku'] == '0'){
                        $stock = $v['stock'];
                        break;
                    }
                }
                $skus_insert = [
                    'goods_id' => $goods_id,
                    'sku' => 0,
                    'guest_price' => $post['skus']['guest_price'] * 100,
                    'user_price' => $post['skus']['user_price'] * 100,
                    'market_price' => $post['skus']['market_price'] * 100,
                    'cost_price' => $post['skus']['cost_price'] * 100,
                    'sales' => $post['skus']['sales'],
                    'stock' => $stock,
                ];
                $this->db->add('skus', $skus_insert);
            }
            if($post['is_sku'] == 'y'){
                // 重新写入会员价格表
                foreach($post['skus'] as $key => $val){
                    foreach($val['member'] as $k => $v){
                        $member_price_insert = [
                            'goods_id' => $goods_id,
                            'sku' => $key,
                            'member_level' => $k,
                            'price' => $v * 100,
                        ];
                        $this->db->add('member_price', $member_price_insert);
                    }
                }
                // 重新写入商品规格表
                foreach($post['skus'] as $key => $val){
                    $stock = 0;
                    foreach($old_skus as $v){
                        if($v['sku'] == $key){
                            $stock = $v['stock'];
                            break;
                        }
                    }
                    $skus_insert = [
                        'goods_id' => $goods_id,
                        'sku' => $key,
                        'guest_price' => $val['guest_price'] * 100,
                        'user_price' => $val['user_price'] * 100,
                        'market_price' => $val['market_price'] * 100,
                        'cost_price' => $val['cost_price'] * 100,
                        'sales' => $val['sales'],
                        'stock' => $stock,
                    ];
                    $this->db->add('skus', $skus_insert);
                }
            }
            $this->db->commit();
        }catch(Throwable $e){
            $this->db->rollBack();
        }
        return true;
    }

    /**
     * 获取单个商品信息
     * 商品表goods为主表
     * 查询要点(需要保障性能，占用服务器资源越少越好，同时也要保障查询速度)：
     * post参数：
     *      商品ID：goods_id 查询主表id
     *      用户ID：user_id 用户id，根据用户来获取价格
     *      用户等级：user_level 用户等级，根据等级来获取价格
     *      选中的SKU：sku 选中的规格，根据规格来获取价格 
     *      购买数量：quantity 购买数量，默认1，也用于计算价格
     * 1. 所需字段：
     *      商品ID：id
     *      商品类型：type
     *      商品标题：title
     *      商品封面图：cover
     *      是否多规格：is_sku
     *      规格数据：skus【skus表】【一对多，id对应goods_id】
     *      商品简介：des
     *      商品详情：content
     *      订单页内容：pay_content
     *      附件选项：attach_user
     *      批量优惠数据：discount【discount表】【一对多，id对应goods_id】
     * 2. 商品价格与用户等级相关
     *      用户ID为空时，使用skus表的guest_price
     *      用户id不为空但是用户等级为空时，使用skus表的user_price
     *      用户id和用户等级都不为空时，需要查询member_price表，表结构为goods_id,sku,member_level, price.
     *      如果member_price表中没有对应等级记录，默认使用上一个等级的价格，如果全部都没有，使用skus表的user_price
     * 结果：返回数组。
     */
    public function getGoodsInfo($post = []){
        $goods_id = (int)$post['goods_id'];
        
        // 查询商品基本信息，只获取需要的字段以优化性能
        $sql = "SELECT id, type, title, cover, is_sku, des, content, pay_content, attach_user, attr_id  
                FROM {$this->table} 
                WHERE id = {$goods_id} AND delete_time IS NULL AND is_on_shelf = 1";
        $goods = $this->db->once_fetch_array($sql);
        
        
        if (empty($goods)) {
            return 'noGoods'; // 商品已下架或被删除
        }

        $goods_cover = $goods['cover'];
        
        // 获取用户信息和SKU参数
        $user_id = isset($post['user_id']) ? (int)$post['user_id'] : 0;
        $user_level = isset($post['user_level']) ? (int)$post['user_level'] : 0;
        $selected_sku_array = isset($post['sku_ids']) ? (array)$post['sku_ids'] : [];
        $quantity = isset($post['quantity']) ? max(1, (int)$post['quantity']) : 1;
        
        // 获取规格数据（无论单规格还是多规格都需要查询）
        $sql = "SELECT sku, guest_price, user_price, market_price, cost_price, stock, sales 
                FROM {$this->table_skus} 
                WHERE goods_id = {$goods_id} 
                ORDER BY user_price ASC";
        $skus_res = $this->db->fetch_all($sql);
        
        // 获取会员价格数据
        $member_price_data = [];
        if ($user_id > 0 && $user_level > 0) {
            $sql = "SELECT sku, member_level, price 
                    FROM " . DB_PREFIX . "member_price 
                    WHERE goods_id = {$goods_id} 
                    ORDER BY member_level DESC";
            $member_price_data = $this->db->fetch_all($sql);
        }
        
        $skus = [];
        
        // 格式化价格（从分转换为元）并应用用户等级价格逻辑
        foreach ($skus_res as $val) {
            $sku_key = $val['sku'];
            
            // 确定价格
            $price = 0;
            if ($user_id == 0) {
                // 用户ID为空时，使用guest_price
                $price = $val['guest_price'] / 100;
            } elseif ($user_level == 0) {
                // 用户等级为空时，使用user_price
                $price = $val['user_price'] / 100;
            } else {
                // 用户ID和等级都不为空时，查询member_price表
                $member_price = 0;
                $found = false;
                
                // 查找当前等级的价格
                foreach ($member_price_data as $mp) {
                    if ($mp['sku'] == $sku_key && $mp['member_level'] == $user_level) {
                        $member_price = $mp['price'] / 100;
                        $found = true;
                        break;
                    }
                }
                
                if ($found) {
                    // 找到对应等级价格
                    $price = $member_price;
                } else {
                    // 没有找到对应等级，查找上一个等级的价格
                    $higher_level_price = 0;
                    $found_higher = false;
                    $higher_level_found = 0;
                    
                    foreach ($member_price_data as $mp) {
                        if ($mp['sku'] == $sku_key && $mp['member_level'] < $user_level) {
                            if (!$found_higher || $mp['member_level'] > $higher_level_found) {
                                $higher_level_price = $mp['price'] / 100;
                                $higher_level_found = $mp['member_level'];
                                $found_higher = true;
                            }
                        }
                    }
                    
                    if ($found_higher) {
                        $price = $higher_level_price;
                    } else {
                        // 全部都没有，使用user_price
                        $price = $val['user_price'] / 100;
                    }
                }
            }
            
            $skus[$sku_key] = [
                'guest_price' => $val['guest_price'] / 100,
                'user_price' => $val['user_price'] / 100,
                'price' => $price, // 当前用户对应的价格
                'market_price' => isset($val['market_price']) ? $val['market_price'] / 100 : 0,
                'cost_price' => isset($val['cost_price']) ? $val['cost_price'] / 100 : 0,
                'stock' => $val['stock'],
                'sales' => $val['sales'],
                'sku' => $sku_key
            ];
        }
        
        // 初始化规格相关数据
        $spec = [];
        $spec_attr = [];
        
        // 如果是多规格商品，获取规格属性数据
        if ($goods['is_sku'] == 'y') {
            $sku_value_ids = [];
            $sku_attr_ids = [];
            
            // 收集所有规格值ID
            foreach ($skus_res as $val) {
                $ids = explode('-', $val['sku']);
                $sku_value_ids = array_merge($sku_value_ids, $ids);
            }
            
            if (!empty($sku_value_ids)) {
                $sku_value_ids = array_unique($sku_value_ids);
                
                // 获取规格值数据
                $sql = "SELECT * FROM " . DB_PREFIX . "sku_value WHERE id IN (" . implode(',', $sku_value_ids) . ")";
                $sku_values = $this->db->fetch_all($sql);
                
                // 收集规格属性ID
                foreach ($sku_values as $val) {
                    $sku_attr_ids[] = $val['attr_id'];
                }
                
                if (!empty($sku_attr_ids)) {
                    $sku_attr_ids = array_unique($sku_attr_ids);
                    
                    // 获取规格属性数据
                    $sql = "SELECT * FROM " . DB_PREFIX . "sku_attr WHERE id IN (" . implode(',', $sku_attr_ids) . ")";
                    $sku_attr = $this->db->fetch_all($sql);
                    
                    // 组装规格数据
                    foreach ($sku_attr as $key => $val) {
                        $spec[$key] = [
                            'sku_attr_id' => $val['id'],
                            'title' => $val['title'],
                            'sku_values' => []
                        ];
                        
                        foreach ($sku_values as $v) {
                            if ($val['id'] == $v['attr_id']) {
                                $spec[$key]['sku_values'][] = [
                                    'id' => $v['id'],
                                    'name' => $v['name']
                                ];
                                $spec_attr[$key][] = $v['id'];
                            }
                        }
                    }
                }
            }
        }
        
        // 获取批量优惠数据
        $discount = [];
        $sql = "SELECT quantity, amount 
                FROM " . DB_PREFIX . "discount 
                WHERE goods_id = {$goods_id} 
                ORDER BY quantity ASC";
        $discount = $this->db->fetch_all($sql);
        
        // 格式化优惠金额（从分转换为元）
        foreach ($discount as &$item) {
            $item['amount'] = $item['amount'] / 100;
        }
        
        // 根据传入的SKU数组来计算价格和库存
        $matched_skus = [];
        $exact_matched_sku = null;
        
        if (!empty($selected_sku_array)) {
            // 传入SKU数组，需要找到匹配的SKU
            sort($selected_sku_array); // 排序确保比较的一致性
            
            foreach ($skus as $sku_key => $sku_data) {
                $sku_ids = explode('-', $sku_key);
                sort($sku_ids); // 排序确保比较的一致性
                
                // 检查传入的SKU数组是否完全等于当前SKU
                if ($selected_sku_array == $sku_ids) {
                    $exact_matched_sku = $sku_data;
                    break;
                }
                
                // 检查传入的SKU数组是否是当前SKU的子集（部分匹配）
                if (count(array_intersect($selected_sku_array, $sku_ids)) === count($selected_sku_array)) {
                    $matched_skus[$sku_key] = $sku_data;
                }
            }
        }

        // var_dump($sku_ids);die;
        
        if ($exact_matched_sku !== null) {
            // 找到完全匹配的SKU，使用该SKU的数据
            $base_price = $exact_matched_sku['price'];
            $market_price = $exact_matched_sku['market_price'];
            $total_stock = $exact_matched_sku['stock'];
            $total_sales = $exact_matched_sku['sales'];
            
            // 应用批量优惠
            $discount_amount = 0;
            foreach ($discount as $discount_rule) {
                if ($quantity >= $discount_rule['quantity']) {
                    $discount_amount = $discount_rule['amount'];
                    break; // 找到匹配的优惠规则就停止
                }
            }
            
            $price = bcmul(bcsub($base_price, $discount_amount, 2), $quantity, 2);
            
            // 价格区间（使用单个SKU的价格）
            $min_price = $price;
            $max_price = $price;
            // 获取成本价
            $cost_price = $exact_matched_sku['cost_price'];
        } elseif (!empty($matched_skus)) {
            // 找到部分匹配的SKU，使用这些SKU的数据
            $prices = [];
            $market_prices = [];
            $cost_prices = [];
            $stocks = [];
            $sales = [];
            
            foreach ($matched_skus as $sku) {
                $prices[] = $sku['price'];
                $market_prices[] = $sku['market_price'];
                $cost_prices[] = $sku['cost_price'];
                $stocks[] = $sku['stock'];
                $sales[] = $sku['sales'];
            }
            
            $base_price = !empty($prices) ? min($prices) : 0;
            $min_price = !empty($prices) ? min($prices) : 0;
            $max_price = !empty($prices) ? max($prices) : 0;
            
            // 应用批量优惠
            $discount_amount = 0;
            foreach ($discount as $discount_rule) {
                if ($quantity >= $discount_rule['quantity']) {
                    $discount_amount = $discount_rule['amount'];
                    break; // 找到匹配的优惠规则就停止
                }
            }
            
            $price = bcmul(bcsub($base_price, $discount_amount, 2), $quantity, 2);
            $market_price = !empty($market_prices) ? min($market_prices) : 0;
            
            // 获取部分匹配SKU中最低成本价
            $cost_price = !empty($cost_prices) ? min($cost_prices) : 0;
            
            // 库存和销售量使用部分匹配SKU的总和
            $total_stock = !empty($stocks) ? array_sum($stocks) : 0;
            $total_sales = !empty($sales) ? array_sum($sales) : 0;
        } else {
            // 未传入SKU或没有匹配的SKU
            $prices = [];
            $market_prices = [];
            $cost_prices = [];
            $stocks = [];
            $sales = [];
            
            foreach ($skus as $sku) {
                // 价格相关：包含所有SKU的价格，让用户能看到价格区间
                $prices[] = $sku['price'];
                $market_prices[] = $sku['market_price'];
                $cost_prices[] = $sku['cost_price'];
                
                // 库存和销售量：包含所有SKU（不管是否有库存）
                $stocks[] = $sku['stock'];
                $sales[] = $sku['sales'];
            }
            
            $base_price = !empty($prices) ? min($prices) : 0;
            $min_price = !empty($prices) ? min($prices) : 0;
            $max_price = !empty($prices) ? max($prices) : 0;
            
            // 应用批量优惠
            $discount_amount = 0;
            foreach ($discount as $discount_rule) {
                if ($quantity >= $discount_rule['quantity']) {
                    $discount_amount = $discount_rule['amount'];
                    break; // 找到匹配的优惠规则就停止
                }
            }
            
            $price = bcmul(bcsub($base_price, $discount_amount, 2), $quantity, 2);
            $market_price = !empty($market_prices) ? min($market_prices) : 0;
            $cost_price = !empty($cost_prices) ? min($cost_prices) : 0;
            
            // 库存和销售量总和
            $total_stock = !empty($stocks) ? array_sum($stocks) : 0;
            $total_sales = !empty($sales) ? array_sum($sales) : 0;
        }

        $cost_price *= 100;

        
        
        // 组装返回数据
        $result = [
            'id' => $goods['id'],
            'attr_id' => $goods['attr_id'],
            'type' => $goods['type'],
            'title' => $goods['title'],
            'cover' => $goods['cover'],
            'is_sku' => $goods['is_sku'],
            'price' => $price, // 根据用户等级、数量计算得到的总价（已优惠 × 数量）
            'unit_price' => $base_price, // 商品单价（未优惠）
            'market_price' => $market_price, // skus表记录中最低价的一个market_price
            'base_price' => isset($base_price) ? $base_price * $quantity : $price, // 原价总价（未优惠 × 数量）
            'discount_amount' => isset($discount_amount) ? $discount_amount * $quantity : 0, // 总优惠金额
            'cost_price' => $cost_price, //成本价
            'stock' => $total_stock, // 库存，根据是否传入SKU决定是单个还是总和，如果没有选中任何sku的时候，默认返回该商品所有的库存，如果选中部分sku，返回可以匹配的sku下的库存，如果sku完全匹配选中，就返回这个sku下的库存
            'sales' => $total_sales, // 销售量，根据是否传入SKU决定是单个还是总和，如果没有选中任何sku的时候，默认返回该商品所有的销售量，如果选中部分sku，返回可以匹配的sku下的销售量，如果sku完全匹配选中，就返回这个sku下的销售量
            'skus' => $skus,
            'spec' => $spec,
            'spec_attr' => $spec_attr,
            'des' => $goods['des'],
            'content' => $goods['content'],
            'pay_content' => $goods['pay_content'],
            'discount' => $discount, // 批量优惠规则
            'quantity' => $quantity, // 购买数量
            'user_id' => $user_id,
            'user_level' => $user_level,
            'min_price' => $min_price,
            'max_price' => $max_price,
            'selected_sku' => $selected_sku_array
        ];
        $attach_user = json_decode($goods['attach_user'], true);
        $result['input']['attach'] = [];
        foreach($attach_user as $key => $val){
            $result['input']['attach'][] = [
                'name' => $key,
                'placeholder' => $val,
                'type' => 'string'
            ];
        }
        $order_required = Option::get('order_required');
        $order_required = json_decode($order_required, true);
        $result['input']['required'] = $order_required;

        // d($result);die;

        doMultiAction('goods_model_get_goods_info', $result, $result);

        $result['id'] = $goods_id;
        $result['price'] = $price;
        $result['cost_price'] = $cost_price;

        foreach($result['skus'] as $key => $val){
            foreach($skus as $k => $v){
                if($key == $k){
                    $result['skus'][$key]['price'] = $v['price'];
                }
            }
        }
        // d($result);die;
        $result['id'] = $goods_id;
        $result['cost_price'] = $cost_price;
        $result['cover'] = $goods_cover;
        
        return $result;
    }

    /**
     * create product
     */
    public function addProduct($productData) {
        $kItem = $dItem = [];
        foreach ($productData as $key => $data) {
            $kItem[] = $key;
            $dItem[] = $data;
        }
        $field = implode(',', $kItem);
        $values = "'" . implode("','", $dItem) . "'";
        $this->db->query("INSERT INTO $this->table ($field) VALUES ($values)");
        return $this->db->insert_id();
    }

    /**
     * update article
     */
    public function updateProduct($logData, $goods_id, $uid = UID) {
        $Item = [];
        foreach ($logData as $key => $data) {
            $Item[] = "$key='$data'";
        }
        $upStr = implode(',', $Item);
        $sql = "UPDATE $this->table SET $upStr WHERE id=$goods_id";
//        echo $sql;die;
        $this->db->query($sql);
    }

    public function getCount() {
        $sql = "SELECT count(*) as num FROM $this->table WHERE type='goods' and delete_time is null";
        $res = $this->db->once_fetch_array($sql);
        return $res['num'];
    }

    /**
     * Gets the number of articles for the specified condition
     *
     * @param int $spot 0:homepage 1:admin
     * @param string $hide
     * @param string $condition
     * @param string $type
     * @return int
     */
    public function getGoodsNum() {

        $data = $this->db->once_fetch_array("SELECT COUNT(*) AS total FROM $this->table where delete_time is null");
        return $data['total'];
    }

    public function getPostCountByUid($uid, $time = 0) {
        $date = '';
        if ($time) {
            $date = "and date > $time";
        }

        $data = $this->db->once_fetch_array("SELECT COUNT(*) AS total FROM $this->table WHERE type='blog' and author=$uid $date");
        return $data['total'];
    }

    public function getOneGoodsForAdmin($goods_id) {

        $sql = "select * from {$this->table} where id={$goods_id} limit 1";
        $goods = $this->db->once_fetch_array($sql);
        $sql = "select * from " . DB_PREFIX . "skus where goods_id={$goods_id}";
        $skus = $this->db->fetch_all($sql);
//        d($skus);die;
        foreach($skus as $key => $val){
            $sql = "select * from " . DB_PREFIX . "member_price where goods_id={$goods_id} and sku='" . $val['sku'] . "'";
            $member_prices = $this->db->fetch_all($sql);
            $skus[$key]['member_prices'] = $member_prices;
        }
        $goods['skus'] = $skus;

        if ($goods) {

            $goods['skus_json'] = json_encode($goods['skus']);

            $goods['title'] = htmlspecialchars($goods['title']);
            $goods['content'] = htmlspecialchars($goods['content']);
            $goods['password'] = htmlspecialchars($goods['password']);
            $goods['template'] = !empty($goods['template']) ? htmlspecialchars(trim($goods['template'])) : 'page';
            return $goods;
        }
        return false;
    }

    public function getGoodsSkusForAdmin($goods_id){

        $sql = "SELECT * FROM $this->table WHERE id=$goods_id";
        $res = $this->db->query($sql);
        $goods = $this->db->fetch_array($res);


        $sql = "SELECT * FROM `" . DB_PREFIX . "skus` where goods_id={$goods_id}";
        $result = $this->db->query($sql);
        $data = [];



        while ($row = $this->db->fetch_array($result)) {
            if($goods['is_sku'] == 'y'){
                $data["skus[{$row['sku']}][guest_price]"] = $row['guest_price'] / 100;
                $data["skus[{$row['sku']}][user_price]"] = $row['user_price'] / 100;
                $data["skus[{$row['sku']}][market_price]"] = $row['market_price'] / 100;
                $data["skus[{$row['sku']}][cost_price]"] = $row['cost_price'] / 100;
                $data["skus[{$row['sku']}][sales]"] = $row['sales'];

                $sql = "SELECT * FROM `" . DB_PREFIX . "member_price` where goods_id={$row['goods_id']}";
                $res = $this->db->query($sql);
                while ($r = $this->db->fetch_array($res)) {
                    if($row['sku'] == $r['sku']){
                        $data["skus[{$row['sku']}][member][{$r['member_level']}]"] = $r['price'] / 100;
                    }

                }

            }else{
                $data['guest_price'] = $row['guest_price'] / 100;
                $data['user_price'] = $row['user_price'] / 100;
                $data['market_price'] = $row['market_price'] / 100;
                $data['cost_price'] = $row['cost_price'] / 100;
            }
        }

//        d($data);die;


        return $data;
    }

    public function getDetail($goods_id) {
        if (empty($goods_id)) {
            return false;
        }
        $sql = "SELECT t1.*, t2.sid, t2.sortname, t2.alias as sort_alias FROM $this->table t1 LEFT JOIN $this->table_sort t2 ON t1.sortid=t2.sid WHERE t1.id=$goods_id";
        $res = $this->db->query($sql);
        $row = $this->db->fetch_array($res);
        if ($row) {
            return $row;
        }
        return false;
    }

    public function getDetails($goods_ids) {
        if (empty($goods_ids) || !is_array($goods_ids)) {
            return false;
        }
        $goods_idsString = implode(',', $goods_ids);
        $sql = "SELECT t1.*, t2.sid, t2.sortname, t2.alias as sort_alias FROM $this->table t1 LEFT JOIN $this->table_sort t2 ON t1.sortid=t2.sid WHERE t1.id IN ($goods_idsString)";
        $res = $this->db->query($sql);
        $rows = array();
        while ($row = $this->db->fetch_array($res)) {
            $rows[] = $row;
        }
        return $rows;
    }

    /**
     * get single article
     * @param $goods_id
     * @return array|false
     */
    public function getOneGoodsForHome($goods_id) {
        $db_prefix = DB_PREFIX;
        $sql = "select * from {$db_prefix}goods where id={$goods_id} limit 1";
        $goods = $this->db->once_fetch_array($sql);

        if($goods['is_on_shelf'] == 0){
            emMsg('该商品已下架！');
        }

        $sql = "select * from {$db_prefix}skus where goods_id={$goods_id}";
        $skus = $this->db->fetch_all($sql);
        $sql ="select * from {$db_prefix}member_price where goods_id={$goods_id}";
        $member_price = $this->db->fetch_all($sql);


        $goods['attach_user'] = json_decode($goods['attach_user'], true);

        if($goods['is_sku'] == 'y'){
            $sku_value_ids = [];
            $sku_attr_ids = [];
            $goods['have_stock_skus'] = [];
            $goods['sku_all'] = [];
            foreach($skus as $key => $val){

                $ids = explode('-', $val['sku']);
                $sku_value_ids = array_merge($sku_value_ids, $ids);

                $price = -1;
                if(LEVEL == -1){
                    $price= $val['guest_price'] / 100;
                }else{
                    foreach($member_price as $v){
                        if($v['member_level'] == LEVEL && $val['sku'] == $v['sku']){
                            $price = $v['price'] / 100;
                        }
                    }
                    $price = $price == -1 ? $val['user_price'] / 100 : $price;
                }
                $val['price'] = $price;

                $goods['sku_all'][$val['sku']] = $val;
                $goods['sku_all'][$val['sku']]['stock'] = $val['stock'];
                if($val['stock'] > 0){
                    $goods['have_stock_skus'][$val['sku']] = $val;
                }
            }


            $sku_value_ids = array_unique($sku_value_ids);
            $sql = "SELECT * FROM {$db_prefix}sku_value WHERE id IN (" . implode(',', $sku_value_ids) . ")";
            $sku_values = $this->db->fetch_all($sql);
            foreach($sku_values as $val){
                $sku_attr_ids[] = $val['attr_id'];
            }
            $sku_attr_ids = array_unique($sku_attr_ids);
            $sql = "SELECT * FROM {$db_prefix}sku_attr WHERE id IN (" . implode(',', $sku_attr_ids) . ")";
            $sku_attr = $this->db->fetch_all($sql);

            $goods['spec'] = [];
            $goods['spec_attr'] = [];
            foreach($sku_attr as $key => $val){
                $goods['spec'][$key] = [
                    'sku_attr_id' => $val['id'],
                    'title' => $val['title'],
                    'sku_values' => []
                ];


                foreach($sku_values as $v){
                    if($val['id'] == $v['attr_id']){
                        $goods['spec'][$key]['sku_values'][] = [
                            'id' => $v['id'],
                            'name' => $v['name']
                        ];
                        $goods['spec_attr'][$key][] = $v['id'];
                    }

                }
            }

            $goods['skus_all_json'] = json_encode($goods['sku_all']);
            $goods['spec_attr_json'] = json_encode($goods['spec_attr']);
            $goods['have_stock_skus_json'] = json_encode($goods['have_stock_skus']);
        }else{
            foreach($skus as $val){
                $price = -1;
                if(LEVEL == -1){
                    $price= $val['guest_price'] / 100;
                }else{
                    foreach($member_price as $v){
                        if($v['member_level'] == LEVEL && $val['sku'] == $v['sku']){
                            $price = $v['price'] / 100;
                        }
                    }
                    $price = $price == -1 ? $val['user_price'] / 100 : $price;
                }



            }
            $goods['spec_attr_json'] = json_encode([]);

            $goods['have_stock_skus'][] = array_merge($val, ['price' => $price, 'stock' => $goods['stock']]);

            $goods['have_stock_skus_json'] = json_encode($goods['have_stock_skus']);
            $goods['skus_all_json'] = json_encode([]);
        }

        $goods['content'] = $this->Parsedown->text($goods['content']);


        return $goods;
    }

    public function getGoodsForAdmin($order = '', $page = 1) {
        $perpage_num = Option::get('admin_article_perpage_num');
        $start_limit = !empty($page) ? ($page - 1) * $perpage_num : 0;
        $limit = "LIMIT $start_limit, " . $perpage_num;


        $sql = "
SELECT 
    g.*, COALESCE(SUM(s.quantity), 0) AS stock
FROM 
    {$this->table} g
LEFT JOIN 
    " . DB_PREFIX . "skus sk ON g.id = sk.goods_id
LEFT JOIN 
    " . DB_PREFIX . "stock s ON sk.goods_id = s.goods_id AND sk.sku = s.sku
where g.delete_time is null
GROUP BY 
    g.id
ORDER BY id desc
$limit;
";

        $res = $this->db->query($sql);
        $logs = [];
        while ($row = $this->db->fetch_array($res)) {
            $row['timestamp'] = $row['create_time'];
            $row['create_time'] = date("Y-m-d H:i", $row['create_time']);
            $row['title'] = !empty($row['title']) ? htmlspecialchars($row['title']) : '无标题';
            $logs[] = $row;
        }
        return $logs;
    }

    public function getGoodsForHome($condition = '', $page = 1, $perPageNum = 10, $order_by = '') {
        $start_limit = !empty($page) ? ($page - 1) * $perPageNum : 0;
        $condition = empty($condition) ? "where g.delete_time is null" : " where " . $condition . " and g.delete_time is null";
        $limit = $perPageNum ? "LIMIT $start_limit, $perPageNum" : '';
        $sql = "
SELECT 
    g.*, 
    COALESCE(SUM(s.quantity), 0) AS stock,
    sk_min.guest_price,
    sk_min.cost_price,
    sk_min.user_price,
    sk_min.market_price,
    mp_min.price AS member_price
FROM 
    {$this->table} g
LEFT JOIN (
    SELECT 
        goods_id, 
        MIN(guest_price) AS guest_price,
        MIN(cost_price) AS cost_price,
        MIN(user_price) AS user_price,
        MIN(market_price) AS market_price
    FROM 
        " . DB_PREFIX . "skus
    GROUP BY 
        goods_id
) sk_min ON g.id = sk_min.goods_id
LEFT JOIN (
    SELECT 
        goods_id, 
        MIN(price) AS price
    FROM 
        " . DB_PREFIX . "member_price
    WHERE 
        member_level = " . LEVEL . "
    GROUP BY 
        goods_id
) mp_min ON g.id = mp_min.goods_id
LEFT JOIN 
    " . DB_PREFIX . "stock s ON g.id = s.goods_id AND sk_min.guest_price = (
        SELECT guest_price 
        FROM " . DB_PREFIX . "skus 
        WHERE goods_id = g.id 
        ORDER BY guest_price ASC 
        LIMIT 1
    )
$condition AND g.is_on_shelf = 1
GROUP BY 
    g.id
ORDER BY 
    {$order_by}
$limit;
";
//echo $sql;die;
        $res = $this->db->query($sql);
        $goods = [];
        while ($row = $this->db->fetch_array($res)) {
            $row['url'] = Url::goods($row['id']);
            $cookiePassword = isset($_COOKIE['em_logpwd_' . $row['id']]) ? addslashes(trim($_COOKIE['em_logpwd_' . $row['id']])) : '';
            if (!empty($row['password']) && $cookiePassword != $row['password']) {
                $row['excerpt'] = '<p>[该商品已加密，请点击标题输入密码访问]</p>';
            }
            $row['log_description'] = $this->Parsedown->text(empty($row['excerpt']) ? $row['content'] : $row['excerpt']);
            $row['market_price'] /= 100;
            $row['cost_price'] /= 100;
            $row['guest_price'] /= 100;
            $row['user_price'] /= 100;

            if(LEVEL == -1){
                $row['price'] = $row['guest_price'];
            }else{
                if(empty($row['member_price'])){
                    $row['price'] = $row['user_price'];
                }else{
                    $row['price'] = $row['member_price'] / 100;
                }
            }





            $goods[] = $row;
        }
//        d($goods);die;
        return $goods;
    }


    /**
     * 删除商品
     */
    public function deleteGoods($goods_id) {
        $timestamp = time();
        $this->db->query("UPDATE $this->table set delete_time={$timestamp} where id=$goods_id");
        return true;
    }
    /**
     * 获取所有主站商品的ID
     */
    public function getAllMasterGoodsId(){
        $sql = "select id from {$this->table} where station=0 and delete_time is null and is_on_shelf=1";
        $masterGoodsIds = $this->db->fetch_all($sql);
        return $masterGoodsIds;
    }

    public function getAllGoods($post = []){
        // 构建基础查询条件 - 使用索引友好的条件顺序
        $where_conditions = ["delete_time IS NULL", "is_on_shelf = 1"];
        
        // 可选的过滤条件（根据post参数）- 参数验证和转义
        if (!empty($post['sort_id']) && is_numeric($post['sort_id'])) {
            $where_conditions[] = "sort_id = " . intval($post['sort_id']);
        }
        
        if (!empty($post['keyword'])) {
            $keyword = $this->db->escape_string(trim($post['keyword']));
            // 使用前缀匹配提高性能
            $where_conditions[] = "title LIKE '" . $keyword . "%'";
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        // 构建高性能SQL查询 - 只查询必要字段，使用覆盖索引
        $sql = "SELECT 
                    id AS goods_id, 
                    type, 
                    title, 
                    sort_id
                FROM {$this->table} 
                WHERE {$where_clause}
                ORDER BY 
                    index_top DESC, 
                    sort_top DESC, 
                    sort_num DESC, 
                    id ASC";
        // return $sql;die;
        $list = $this->db->fetch_all($sql);
        
        return $list;
    }

    /**
     * 前台 - 获取全部商品
     */
    function getHomeAllGoods($post){
        global $stationData;

//        d($stationData);die;

        $sort_id = $post['sort_id'];
        $keyword = $post['keyword'];
        $where = "";
        if(!empty($keyword)){
            $where .= " and g.title like '%{$keyword}%'";
        }
        if(!empty($sort_id) && $sort_id != 0){
            $where .= " and g.sort_id={$sort_id}";
        }
        $join = "";
        $field = "";
        $premium_select = "";
        if($stationData['id'] == 0){ // 主站/分站 商品过滤
            $where .= " and g.station_id=0";
        }else{
//            d($stationData);die;
            if($stationData['master_goods'] == 1){ // 全部显示主站商品
                $where .= " and (g.station_id={$stationData['id']} or g.station_id=0)";
                $join .= " left join {$this->table_station_goods} sg on sg.goods_id=g.id";
                $field .= ", sg.premium";
                $premium_select = ", IFNULL(sg.premium, 0) as premium";
            }
            if($stationData['master_goods'] == 2){ // 全部隐藏主站商品
                $where .= " and g.station_id={$stationData['id']}";
            }
            if($stationData['master_goods'] == 3){ // 自定义显示主站商品
                $join .= " inner join {$this->table_station_goods} sg on sg.goods_id=g.id and sg.is_show='y'";
                $field .= ", sg.premium";
                $premium_select = ", IFNULL(sg.premium, 0) as premium";
            }

            if($stationData['master_sort'] == 2){ // 全部隐藏主站分类
                $join .= " inner join {$this->table_sort} s on s.sid=g.sort_id and s.station_id={$stationData['id']}";
            }
            if($stationData['master_sort'] == 3){ // 自定义显示主站分类
                $join .= " inner join {$this->table_station_sort} ss on ss.sort_id=g.sort_id and ss.is_show='y'";
            }
        }
        
        $sql = "SELECT
            g.title, g.cover, g.des, g.type, g.id as goods_id, g.des as goods_des, COALESCE(sku_stats.total_sales, 0) as sales, g.sort_id, COALESCE(sku_stats.total_stock, 0) as stock,
            g.index_top, g.sort_top, g.sort_num, g.station_id, g.create_time, g.is_on_shelf, g.delete_time, g.is_sku,
            sku.goods_id as sku_goods_id, sku.sku, sku.guest_price, sku.market_price, sku.user_price, sku.cost_price, sku.stock as sku_stock,
            mp.goods_id as mp_goods_id, mp.sku as mp_sku, mp.member_level as mp_level, mp.price as mp_price
            {$premium_select} {$field}
        FROM {$this->table} g
        LEFT JOIN {$this->table_skus} sku ON sku.goods_id = g.id
        LEFT JOIN {$this->table_member_price} mp ON mp.goods_id = g.id AND mp.sku = sku.sku
        LEFT JOIN (
            SELECT goods_id, SUM(sales) as total_sales, SUM(stock) as total_stock
            FROM {$this->table_skus}
            GROUP BY goods_id
        ) sku_stats ON sku_stats.goods_id = g.id
        {$join}
        WHERE g.is_on_shelf = 1 AND g.delete_time IS NULL {$where}
        ORDER BY g.index_top DESC, g.sort_top DESC, g.sort_num DESC, g.id asc;";

        $data = $this->db->fetch_all($sql);
//        d($data);die;
        $goods = [];
        foreach($data as $val){
            if(isset($goods[$val['goods_id']])){
                if (!is_null($val['mp_level'])) {
                    $goods[$val['goods_id']]['mp'][$val['mp_level']] = $val['mp_price'];
                }
            }else{
                $goods[$val['goods_id']] = $val;
                $goods[$val['goods_id']]['url'] = Url::goods($val['goods_id']);
                if (!is_null($val['mp_level'])) {
                    $goods[$val['goods_id']]['mp'][$val['mp_level']] = $val['mp_price'];
                } else {
                    $goods[$val['goods_id']]['mp'] = [];
                }
            }
        }
//        d($goods);die;
        foreach($goods as $key => $val){
            // 处理分站对主站商品的加价逻辑
            $isMasterGoods = isset($val['station_id']) && $val['station_id'] == 0; // 判断是否为主站商品
            $premiumRate = 0.1; // 默认不加价
            
            // 如果存在premium字段，则使用该字段的值作为加价比例
            if(isset($val['premium'])){
                $premiumRate = 1 + $val['premium']; // 注意这里应该是百分比
            }
            
            if(LEVEL == -1){
                $goods[$key]['price'] = $val['guest_price'];
                // 如果是分站且商品来自主站，则应用加价
                if($stationData['id'] != 0 && $isMasterGoods){
                    $goods[$key]['price'] = round($val['guest_price'] * $premiumRate);
                }
            }else if(LEVEL == 0){
                $goods[$key]['price'] = $val['user_price'];
                // 如果是分站且商品来自主站，则应用加价
                if($stationData['id'] != 0 && $isMasterGoods){
                    $goods[$key]['price'] = round($val['user_price'] * $premiumRate);
                }
            }else{
                if(!empty($val['mp'])){
                    $price_set = false;
                    foreach($val['mp'] as $k => $v){
                        if($k == LEVEL){
                            $goods[$key]['price'] = $v;
                            // 如果是分站且商品来自主站，则应用加价
                            if($stationData['id'] != 0 && $isMasterGoods){
                                $goods[$key]['price'] = round($v * $premiumRate);
                            }
                            $price_set = true;
                        }
                    }
                    if(!$price_set){
                        $goods[$key]['price'] = $val['user_price'];
                        // 如果是分站且商品来自主站，则应用加价
                        if($stationData['id'] != 0 && $isMasterGoods){
                            $goods[$key]['price'] = round($val['user_price'] * $premiumRate);
                        }
                    }
                }else{
                    $goods[$key]['price'] = $val['user_price'];
                    // 如果是分站且商品来自主站，则应用加价
                    if($stationData['id'] != 0 && $isMasterGoods){
                        $goods[$key]['price'] = round($val['user_price'] * $premiumRate);
                    }
                }
            }

            $goods[$key]['price'] = $goods[$key]['price'] / 100;
            $goods[$key]['market_price'] = $goods[$key]['market_price'] / 100;
        }

        doMultiAction('home_goods_list', $goods, $goods);

        return $goods;
    }


}
