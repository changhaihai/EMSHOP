<?php
/**
 * @package EMSHOP
 */

class Sort_Model {

    private $db;
    private $table;
    private $table_blog;
    private $table_goods;
    private $table_station_sort;
    private $table_station_goods;

    function __construct() {
        $this->table = DB_PREFIX . 'sort';
        $this->table_blog = DB_PREFIX . 'blog';
        $this->table_goods = DB_PREFIX . 'goods';
        $this->table_station_sort = DB_PREFIX . 'station_sort';
        $this->table_station_goods = DB_PREFIX . 'station_goods';
        $this->db = Database::getInstance();
    }

    /**
     * 前台 - 获取全部商品分类
     */
    function getHomeAllGoodsSort(){
        global $stationData;
//        d($stationData);
        $field = "s.sid, s.sortname, COUNT(g.id) AS goods_count, s.sortimg";
        $group_by = "group by s.sid";
        $order_by = "order by s.taxis desc, sid asc";
        $where = "where s.type='goods'";

        $sql = "select {$field} from {$this->table} s 
                LEFT JOIN {$this->table_goods} g ON s.sid = g.sort_id and g.delete_time is null and g.is_on_shelf = 1";
        $join = "";
        if($stationData['id'] == 0){
            $where .= " and s.station_id=0";
            $sql .= " and g.station_id=0";
        }else{
            if($stationData['master_sort'] == 1){ // 全部显示
                $where .= " and (s.station_id=0 or s.station_id={$stationData['id']})";
                if($stationData['master_goods'] == 1){
                    $sql .= " and (g.station_id=0 or g.station_id={$stationData['id']})";
                }
                if($stationData['master_goods'] == 2){
                    $sql .= " and (g.station_id={$stationData['id']})";
                }
                if($stationData['master_goods'] == 3){

                }
            }
            if($stationData['master_sort'] == 2){ // 全部隐藏
                $where .= " and s.station_id={$stationData['id']}";
            }
            if($stationData['master_sort'] == 3){ // 自定义
                $join .= " inner join {$this->table_station_sort} ss on ss.sort_id=s.sid and ss.is_show='y'";
            }

            if($stationData['master_goods'] == 3){
                $join .= " inner join {$this->table_station_goods} sg on sg.goods_id=g.id and sg.is_show='y'";
            }
        }
        $sql .= " {$join} {$where} {$group_by} {$order_by}";
//        echo $sql;
        $res = $this->db->fetch_all($sql);
        foreach($res as &$val){
            $val['sort_url'] = Url::sort($val['sid']);
        }
        return $res;
    }

    function getSorts($type) {
        $sorts = [];
        $query = $this->db->query("SELECT * FROM $this->table where `type`='{$type}' ORDER BY taxis desc, sid asc");
        while ($row = $this->db->fetch_array($query)) {
            $data = $this->db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog WHERE sortid=" . $row['sid'] . " AND hide='n' AND checked='y' AND type='blog'");
            $logNum = $data['total'];
            $sortData = array(
                'type' => $row['type'],
                'lognum'       => $logNum,
                'sortname'     => htmlspecialchars($row['sortname']),
                'alias'        => $row['alias'],
                'description'  => htmlspecialchars($row['description']),
                'kw'           => htmlspecialchars($row['kw']),
                'title_origin' => $row['title'],
                'title'        => htmlspecialchars(Sort::formatSortTitle($row['title'], $row['sortname'])),
                'sid'          => (int)$row['sid'],
                'taxis'        => (int)$row['taxis'],
                'pid'          => (int)$row['pid'],
                'template'     => htmlspecialchars($row['template']),
                'sortimg'      => htmlspecialchars($row['sortimg'])
            );
            if ($sortData['pid'] == 0) {
                $sortData['children'] = [];
            } elseif (isset($sorts[$row['pid']])) {
                $sorts[$row['pid']]['children'][] = $row['sid'];
            }
            $sorts[$row['sid']] = $sortData;
        }
        return $sorts;
    }

    function updateSort($sortData, $sid) {
        $Item = [];
        foreach ($sortData as $key => $data) {
            $Item[] = "$key='$data'";
        }
        $upStr = implode(',', $Item);
        $this->db->query("update $this->table set $upStr where sid=$sid");
    }

    public function addSort($data) {
        $kItem = $dItem = [];
        foreach ($data as $key => $val) {
            $kItem[] = $key;
            $dItem[] = $val;
        }
        $field = implode(',', $kItem);
        $values = "'" . implode("','", $dItem) . "'";
        $this->db->query("INSERT INTO $this->table ($field) VALUES ($values)");
        return $this->db->insert_id();
    }

    function deleteSort($sid) {
        $this->db->query("update $this->table_goods set sort_id=-1 where sort_id={$sid}");
        $this->db->query("update $this->table set pid=0 where pid=$sid");
        $this->db->query("DELETE FROM $this->table where sid=$sid");
    }

    function getOneSortById($sid) {
        $sql = "select * from $this->table where sid=$sid";
        $res = $this->db->query($sql);
        $row = $this->db->fetch_array($res);
        $sortData = [];
        if ($row) {
            $sortData = array(
                'sortname'     => htmlspecialchars(trim($row['sortname'])),
                'alias'        => $row['alias'],
                'pid'          => $row['pid'],
                'title_origin' => $row['title'],
                'title'        => htmlspecialchars(Sort::formatSortTitle($row['title'], $row['sortname'])),
                'kw'           => htmlspecialchars($row['kw']),
                'description'  => htmlspecialchars(trim($row['description'])),
                'template'     => !empty($row['template']) ? htmlspecialchars(trim($row['template'])) : 'log_list',
                'sortimg'      => htmlspecialchars(trim($row['sortimg'])),
            );
        }
        return $sortData;
    }

    function getSortByAlias($alias) {
        if (empty($alias)) {
            return [];
        }
        $alias = addslashes($alias);
        $res = $this->db->query("SELECT * FROM $this->table WHERE alias = '$alias'");
        $row = $this->db->fetch_array($res);
        return $row;
    }

    function getSortName($sid) {
        if ($sid > 0) {
            $res = $this->db->query("SELECT sortname FROM $this->table WHERE sid = $sid");
            $row = $this->db->fetch_array($res);
            $sortName = htmlspecialchars($row['sortname']);
        } else {
            $sortName = '未分类';
        }
        return $sortName;
    }


    /**
     * 用户获取商品分类 v2
     * 查询说明（要求性能最好，占用资源最少）：
     * 1，参数post内容说明：
     *      goods_title：搜索商品标题 - 如存在，则仅统计包含该标题的商品数量  
     *      includeEmpty：是否查询无商品分类 - 默认为true，不管分类下是否有商品，都要返回该分类，如果是false，则不返回没有商品的分类
     * 2. sort分类表为主表，排序按照字段taxis(desc)，sid(asc)排序，type字段等于goods时为商品分类
     * 3. 需要分类表字段：
     *      sid(分类ID)
     *      sortname（分类名称）
     *      goods_count(统计其下商品数量: 分类表sid对应商品表的sort_id)
     */
    function getGoodsSort($post = []){
        $goods_title = isset($post['goods_title']) ? trim($post['goods_title']) : '';
        $include_empty = isset($post['includeEmpty']) ? filter_var($post['includeEmpty'], FILTER_VALIDATE_BOOLEAN) : true;
        
        // 如果不需要包含无商品分类，使用INNER JOIN直接获取有商品的分类，性能更优
        if (!$include_empty) {
            // 直接通过JOIN获取有商品的分类，一次查询完成
            $goods_where = "g.delete_time IS NULL AND g.is_on_shelf = 1";
            if (!empty($goods_title)) {
                $goods_title = $this->db->escape_string($goods_title);
                $goods_where .= " AND g.title LIKE '" . $goods_title . "%'";
            }
            
            $sql = "SELECT DISTINCT 
                        s.sid AS sort_id, 
                        s.sortname,
                        COUNT(g.id) AS goods_count
                    FROM {$this->table} s
                    INNER JOIN {$this->table_goods} g ON s.sid = g.sort_id AND {$goods_where}
                    WHERE s.type = 'goods'
                    GROUP BY s.sid, s.sortname
                    ORDER BY s.taxis DESC, s.sid ASC";
            
            $data = $this->db->fetch_all($sql);
            
            // 确保goods_count为整数类型
            foreach ($data as &$item) {
                $item['goods_count'] = (int)$item['goods_count'];
            }
            
            return $data;
        }
        
        // 需要包含无商品分类的情况（默认行为）
        // 先获取所有分类
        $sort_sql = "SELECT sid AS sort_id, sortname FROM {$this->table} WHERE type = 'goods' ORDER BY taxis DESC, sid ASC";
        $sorts = $this->db->fetch_all($sort_sql);
        
        // 初始化商品数量为0
        foreach ($sorts as &$sort) {
            $sort['goods_count'] = 0;
        }
        
        // 如果没有商品标题搜索，使用优化的COUNT查询
        if (empty($goods_title)) {
            // 使用子查询优化，避免GROUP BY
            $count_sql = "SELECT sort_id, COUNT(*) AS goods_count FROM (
                SELECT sort_id FROM {$this->table_goods} 
                WHERE delete_time IS NULL AND is_on_shelf = 1 AND sort_id > 0
            ) AS active_goods GROUP BY sort_id";
            
            $counts = $this->db->fetch_all($count_sql);
            
            // 将统计数据合并到分类数组中
            $sort_counts = [];
            foreach ($counts as $count) {
                $sort_counts[$count['sort_id']] = (int)$count['goods_count'];
            }
            
            foreach ($sorts as &$sort) {
                if (isset($sort_counts[$sort['sort_id']])) {
                    $sort['goods_count'] = $sort_counts[$sort['sort_id']];
                }
            }
        } else {
            // 有标题搜索时，使用索引友好的查询
            $goods_title = $this->db->escape_string($goods_title);
            
            // 尝试使用前缀匹配，提高索引利用率
            $title_condition = "title LIKE '" . $goods_title . "%'";
            
            $count_sql = "SELECT sort_id, COUNT(*) AS goods_count FROM (
                SELECT sort_id FROM {$this->table_goods} 
                WHERE delete_time IS NULL AND is_on_shelf = 1 AND sort_id > 0 AND {$title_condition}
            ) AS filtered_goods GROUP BY sort_id";
            
            $counts = $this->db->fetch_all($count_sql);
            
            // 将统计数据合并到分类数组中
            $sort_counts = [];
            foreach ($counts as $count) {
                $sort_counts[$count['sort_id']] = (int)$count['goods_count'];
            }
            
            foreach ($sorts as &$sort) {
                if (isset($sort_counts[$sort['sort_id']])) {
                    $sort['goods_count'] = $sort_counts[$sort['sort_id']];
                }
            }
        }
        
        return $sorts;
    }

}
