<?php
/**
 * article and page model
 *
 * @package EMLOG
 * @link https://www.emlog.net
 */

class Station_Model {

    private $db;
    private $Parsedown;
    private $table;
    private $table_user;
    private $table_sort;
    private $db_prefix;
    private $timestamp;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->table = DB_PREFIX . 'order';
        $this->table_user = DB_PREFIX . 'user';
        $this->db_prefix = DB_PREFIX;
        $this->table_sort = DB_PREFIX . 'sort';
        $this->Parsedown = new Parsedown();
        $this->Parsedown->setBreaksEnabled(true); //automatic line wrapping
        $this->timestamp = time();
    }

    /**
     * 创建分站
     */
    public function create($user_id, $level_id, $amount){
        $current_domain = getDomain();
        $sql = "select * from {$this->db_prefix}station where domain = '{$current_domain}' or domain_2 = '{$current_domain}'";
        $station = $this->db->once_fetch_array($sql);
        $pid = empty($station) ? 0 : $station['id'];
        $insert = [
            'user_id' => $user_id,
            'pid' => $pid,
            'level_id' => $level_id,
            'amount' => $amount,
            'create_time' => $this->timestamp,
            'station_unique' => generateUUIDv4()
        ];
        $this->db->add('station', $insert);
    }

    /**
     * 返回当前分站的信息
     */
    public function getStationInfo(){
        $current_domain = getDomain();
        $sql = "select * from {$this->db_prefix}station where domain = '{$current_domain}' or domain_2 = '{$current_domain}'";
//        echo $sql;die;
        $station = $this->db->once_fetch_array($sql);
//        d($station);die;
        $sql = "select * from {$this->db_prefix}station_plugin where type = 'tpl' and pc_switch = 'y'";
        $res = $this->db->once_fetch_array($sql);
        $pc_tpl = empty($res) ? 'default' : $res['plugin_name_en'];
        $sql = "select * from {$this->db_prefix}station_plugin where type = 'tpl' and tel_switch = 'y'";
        $res = $this->db->once_fetch_array($sql);
        $tel_tpl = empty($res) ? 'default' : $res['plugin_name_en'];

        if(empty($station)){
            return ['id' => 0];
        }else{
            $station['pc_tpl'] = $pc_tpl;
            $station['tel_tpl'] = $tel_tpl;
            $station['roll_bulletin'] = $station['roll_notice'];
            $station['home_bulletin'] = $station['home_notice'];
            return $station;
        }
    }


}
