<?php

require_once 'globals.php';
LoginAuth::checkToken();
$goodsModel = new Goods_Model();

$post = [
    'goods_id' => Input::postIntVar('goods_id', 0),
    'type' => Input::postStrVar('type'),
    'sort_id' => Input::postStrVar('sort_id', -1),
    'title' => Input::postStrVar('title'),
    'cover' => Input::postStrVar('cover'),
    'is_sku' => Input::postStrVar('is_sku'),
    'attr_id' => Input::postIntVar('attr_id', 0),
    'skus' => Input::postStrArray('skus', []),
    'des' => Input::postStrVar('des'),
    'content' => Input::postStrVar('content'),
    'pay_content' => Input::postStrVar('pay_content'),
    'attach_user' => Input::postStrVar('attach_user', '{}'),
    'discount' => Input::postStrArray('discount'),
    'is_on_shelf' => Input::postIntVar('is_on_shelf', 0),
    'index_top' => Input::postIntVar('index_top', 0),
    'sort_top' => Input::postIntVar('sort_top', 0),
    'sort_num' => Input::postIntVar('sort_num'),
];
$post['attach_user'] = json_decode(stripslashes($post['attach_user']), true);
if(empty($post['type'])) Ret::error('请选择商品类型');
if($post['sort_id'] == -1) Ret::error('请选择商品分类');
if(empty($post['title'])) Ret::error('请输入商品名称');
if(empty($post['is_sku'])) Ret::error('请选择规格类型');
if($post['is_sku'] == 'n'){
    if(isEmpty($post['skus']['guest_price'])) Ret::error('请输入游客访问价格');
    $post['skus']['user_price'] = isEmpty($post['skus']['user_price']) ? $post['skus']['guest_price'] : $post['skus']['user_price'];
    $post['skus']['market_price'] = isEmpty($post['skus']['market_price']) ? $post['skus']['guest_price'] : $post['skus']['market_price'];
    $post['skus']['cost_price'] = isEmpty($post['skus']['cost_price']) ? 0 : $post['skus']['cost_price'];
    $post['skus']['sales'] = empty($post['skus']['sales']) ? 0 : $post['skus']['sales'];
    $post['skus']['member'] = empty($post['skus']['member']) ? [] : $post['skus']['member'];
    $last_price = $post['skus']['user_price'];
    foreach($post['skus']['member'] as $key => $val){
        $post['skus']['member'][$key] = isEmpty($val) ? $last_price : $val;
        $last_price = isEmpty($val) ? $last_price : $val;
    }
}
if($post['is_sku'] == 'y'){
    if(empty($post['attr_id'])) Ret::error('请选择规格模板');
    if(empty($post['skus'])) Ret::error('请设置规格属性');
    foreach($post['skus'] as $key => $val){
        if(empty($val['guest_price'])) Ret::error('请输入游客访问价格');
        $post['skus'][$key]['user_price'] = isEmpty($val['user_price']) ? $val['guest_price'] : $val['user_price'];
        $post['skus'][$key]['market_price'] = isEmpty($val['market_price']) ? $val['guest_price'] : $val['market_price'];
        $post['skus'][$key]['cost_price'] = isEmpty($val['cost_price']) ? 0 : $val['cost_price'];
        $post['skus'][$key]['sales'] = empty($val['sales']) ? 0 : $val['sales'];
        $post['skus'][$key]['member'] = empty($val['member']) ? [] : $val['member'];
        $last_price = $post['skus'][$key]['user_price'];
        foreach($post['skus'][$key]['member'] as $k => $v){
            $post['skus'][$key]['member'][$k] = isEmpty($v) ? $last_price : $v;
            $last_price = isEmpty($v) ? $last_price : $v;
        }
    }
}
if(empty($post['goods_id'])){
    $goodsModel->addGoods($post);
    die(json_encode(['msg' => '商品已添加', 'type' => 'add']));
}else{
    $goodsInfo = $goodsModel->getGoodsInfo([
        'goods_id' => $post['goods_id'],
    ]);
    $goodsModel->editGoods($post['goods_id'], $post);
    die(json_encode(['msg' => '商品已更新', 'type' => 'edit']));
}

