<?php defined('EM_ROOT') || exit('access denied!'); ?>


<div class="layui-tabs" style="margin-bottom: 12px;" lay-options="{trigger: false}">
    <ul class="layui-tabs-header">
        <li class="layui-this"><a href="./shop.php">基础设置</a></li>
        <li><a href="./shop.php?action=gg">公告设置</a></li>
        <li><a href="./shop.php?action=btx">下单必填项</a></li>

    </ul>
</div>
<div class="layui-panel">
    <div style="padding: 20px;">
        <form action="shop.php?action=index_save" method="post" name="setting_form" id="setting_form" class="layui-form">

            <div class="layui-form-item">
                <div class="layui-input-block">
                    <input type="checkbox" value="y" name="sales_switch" title="显示销量" <?= $sales_switch == 'y' ? 'checked' : '' ?>>
                </div>
                <div class="layui-input-block">
                    <input type="checkbox" value="y" name="stock_switch" title="显示库存" <?= $stock_switch == 'y' ? 'checked' : '' ?>>
                </div>
                <div class="layui-input-block">
                    <input type="checkbox" value="y" name="balance_switch" title="开启余额支付" <?= $balance_switch == 'y' ? 'checked' : '' ?>>
                </div>
            </div>

            <div class="layui-form-item">
                <label class="layui-form-label">购买后跳转页面</label>
                <div class="layui-input-block">
                    <input type="radio" name="pay_redirect" value="list" title="订单列表" <?= $pay_redirect == 'list' ? 'checked' : '' ?>>
                </div>
                <div class="layui-input-block">
                    <input type="radio" name="pay_redirect" value="kami" title="卡密详情页(非卡密类商品不生效)" <?= $pay_redirect == 'kami' ? 'checked' : '' ?>>
                </div>
            </div>

            <div class="layui-form-item">
                <label class="layui-form-label">卡密发货顺序</label>
                <div class="layui-input-block">
                    <input type="radio" name="kami_order" value="asc" title="先售旧卡" <?= $kami_order == 'asc' ? 'checked' : '' ?>>
                </div>
                <div class="layui-input-block">
                    <input type="radio" name="kami_order" value="desc" title="先售新卡" <?= $kami_order == 'desc' ? 'checked' : '' ?>>
                </div>
                <div class="layui-input-block">
                    <input type="radio" name="kami_order" value="random" title="随机售卡" <?= $kami_order == 'random' ? 'checked' : '' ?>>
                </div>
            </div>

            <input name="token" id="token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit lay-filter="demo1">保存设置</button>
                    <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                </div>
            </div>

        </form>
    </div>
</div>



<script src="./tinymce/tinymce.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
<script>
    $(function () {
        $("#menu-system").attr('class', 'admin-menu-item has-list in');
        $("#menu-system .fa-angle-right").attr('class', 'admin-arrow fa fa-angle-right active');
        $("#menu-system > .submenu").css('display', 'block');
        $('#menu-shop > a').attr('class', 'menu-link active')

        // 提交表单
        $("#setting_form").submit(function (event) {
            event.preventDefault();
            submitForm("#setting_form");
        });
    });


</script>
