<?php defined('EM_ROOT') || exit('access denied!'); ?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8">
<!--    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name=renderer content=webkit>
    <title>管理中心 - <?= Option::get('blogname') ?></title>
    <link rel="shortcut icon" href="<?= EM_URL ?>admin/views/images/favicon.ico"/>

    <link rel="stylesheet" href="<?= EM_URL ?>admin/views/layui-v2.11.6//layui/css/layui.css">
    <script src="<?= EM_URL ?>admin/views/layui-v2.11.6/layui/layui.js"></script>


    <!-- jquery v3.5.1 -->
    <script src="<?= EM_URL ?>admin/views/js/jquery.min.3.5.1.js"></script>



    <!-- 字体 -->
    <link rel="stylesheet" type="text/css" href="<?= EM_URL ?>admin/views/font-awesome-4.7.0/css/font-awesome.min.css">



    <link rel="stylesheet" href="<?= EM_URL ?>admin/views/css/style.css?v=<?= time() ?>">

    <script src="<?= EM_URL ?>admin/views/js/common.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>

    <script>
        $(function(){
            var Accordion = function(el, multiple) {
                this.el = el || {};
                this.multiple = multiple || false;

                // Variables privadas
                var links = this.el.find('.link');
                // Evento
                links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown)
            }

            Accordion.prototype.dropdown = function(e) {
                var $el = e.data.el;
                $this = $(this),
                    $next = $this.next();

                $this.find('.admin-arrow').toggleClass('active')

                $next.slideToggle();
                $this.parent().toggleClass('open');

                if (!e.data.multiple) {
                    $el.find('.submenu').not($next).slideUp().parent().removeClass('open');
                    $el.find('.submenu').not($next).slideUp().parent().children().children().removeClass('active');
                };
            }

            var accordion = new Accordion($('#accordion'), false);
        })
    </script>
    <?php doAction('adm_head') ?>
</head>
<body id="page-top">
<div id="editor-md-dialog"></div>
<div id="admin-container">
    <!-- 遮罩层 -->
    <div class="overlay"></div>


    <nav class="menu-container" id="left-menu">
        <a class="logo" href="<?= EM_URL ?>admin">
            <?= Option::get('blogname') ?>
        </a>
        <ul id="accordion" class="menu accordion">
            <li class="admin-menu-item" id="menu-dashboard">
                <a href="<?= EM_URL ?>admin" class="menu-link"><i class="fa fa-one fa-dashboard"></i>控制台</a>
            </li>

            <li class="admin-menu-item has-submenu" id="menu-goods">
                <div class="menu-link link">
                    <i class="fa fa-one fa-cube"></i><span>商品管理</span><i class="admin-arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-goods-list" class="admin-menu-item"><a href="<?= EM_URL ?>admin/goods.php" class="menu-link">-&nbsp;&nbsp;商品列表</a></li>
<!--                    <li id="menu-stock-list" class="admin-menu-item"><a href="stock.php" class="menu-link">-&nbsp;&nbsp;库存管理</a></li>-->
                    <li id="menu-sort-list" class="admin-menu-item"><a href="<?= EM_URL ?>admin/sort.php" class="menu-link">-&nbsp;&nbsp;商品分类</a></li>
                    <li id="menu-sku-list" class="admin-menu-item"><a href="<?= EM_URL ?>admin/sku.php" class="menu-link">-&nbsp;&nbsp;商品规格</a></li>
                </ul>
            </li>
            <li class="admin-menu-item has-submenu" id="menu-order">
                <div class="menu-link link">
                    <i class="fa fa-one fa-list-ul"></i>订单管理<i class="admin-arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-order-goods" class="admin-menu-item"><a href="<?= EM_URL ?>admin/order.php" class="menu-link">-&nbsp;&nbsp;商品订单</a></li>
                    <li id="menu-order-withdraw" class="admin-menu-item"><a href="<?= EM_URL ?>admin/withdraw.php" class="menu-link">-&nbsp;&nbsp;提现申请</a></li>
                    <li id="menu-order-charge" class="admin-menu-item"><a href="<?= EM_URL ?>admin/charge.php" class="menu-link">-&nbsp;&nbsp;充值订单</a></li>
                </ul>
            </li>

            <li class="admin-menu-item has-submenu" id="menu-user">
                <div class="menu-link link">
                    <i class="fa fa-one fa-user"></i>用户管理<i class="admin-arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-user-default" class="admin-menu-item"><a href="<?= EM_URL ?>admin/user.php" class="menu-link">-&nbsp;&nbsp;用户管理</a></li>
                    <li id="menu-user-member" class="admin-menu-item"><a href="<?= EM_URL ?>admin/member.php" class="menu-link">-&nbsp;&nbsp;会员等级</a></li>
                </ul>
            </li>
            <li class="admin-menu-item has-submenu" id="menu-blog">
                <div class="menu-link link">
                    <i class="fa fa-one fa-columns"></i>博客管理<i class="admin-arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-blog-list" class="admin-menu-item"><a href="<?= EM_URL ?>admin/article.php" class="menu-link">-&nbsp;&nbsp;文章列表</a></li>
                    <li id="menu-blog-sort" class="admin-menu-item"><a href="<?= EM_URL ?>admin/sort.php?type=blog" class="menu-link">-&nbsp;&nbsp;文章分类</a></li>
                    <li id="menu-blog-widgets" class="admin-menu-item"><a href="<?= EM_URL ?>admin/widgets.php" class="menu-link">-&nbsp;&nbsp;边栏管理</a></li>
                    <li id="menu-blog-link" class="admin-menu-item"><a href="<?= EM_URL ?>admin/link.php" class="menu-link">-&nbsp;&nbsp;友情链接</a></li>
                </ul>
            </li>
            <li class="admin-menu-item has-submenu" id="menu-station">
                <div class="menu-link link">
                    <i class="fa fa-one fa-sitemap"></i>分站管理<i class="admin-arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-station-lists" class="admin-menu-item"><a href="<?= EM_URL ?>admin/station.php?action=lists" class="menu-link">-&nbsp;&nbsp;分站列表</a></li>
                    <li id="menu-station-level" class="admin-menu-item"><a href="<?= EM_URL ?>admin/station.php?action=level" class="menu-link">-&nbsp;&nbsp;分站等级</a></li>
                </ul>
            </li>
            <li class="admin-menu-item has-submenu" id="menu-appearance">
                <div class="menu-link link">
                    <i class="fa fa-one fa-inbox"></i>外观设置<i class="admin-arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-template" class="admin-menu-item"><a href="<?= EM_URL ?>admin/template.php" class="menu-link">-&nbsp;&nbsp;模板管理</a></li>
                    <li id="menu-navi" class="admin-menu-item"><a href="<?= EM_URL ?>admin/navbar.php" class="menu-link">-&nbsp;&nbsp;导航管理</a></li>
                    <li id="menu-page" class="admin-menu-item"><a href="<?= EM_URL ?>admin/page.php" class="menu-link">-&nbsp;&nbsp;页面管理</a></li>
                </ul>
            </li>

            <li id="menu-plugin" class="admin-menu-item">
                <a href="<?= EM_URL ?>admin/plugin.php" class="menu-link"><i class="fa fa-one fa-sliders"></i>插件管理</a>
            </li>
            <li  class="admin-menu-item has-submenu" id="menu-system">
                <div class="menu-link link">
                    <i class="fa fa-one fa-cog"></i>系统管理<i class="admin-arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-setting" class="admin-menu-item"><a href="<?= EM_URL ?>admin/setting.php" class="menu-link">-&nbsp;&nbsp;基础设置</a></li>
                    <li id="menu-shop" class="admin-menu-item"><a href="<?= EM_URL ?>admin/shop.php" class="menu-link">-&nbsp;&nbsp;商城配置</a></li>
                    <li id="menu-media" class="admin-menu-item"><a href="<?= EM_URL ?>admin/media.php" class="menu-link">-&nbsp;&nbsp;资源管理</a></li>
                </ul>
            </li>
            <li id="menu-store" class="admin-menu-item">
                <a href="<?= EM_URL ?>admin/store.php" class="menu-link">
                    <i class="fa fa-one fa-shopping-cart"></i>应用商店
                </a>
            </li>

            <?php if(!defined('DEMO_MODE') || DEMO_MODE != true): ?>

            <?php if (Register::isRegLocal()) : ?>
                <li id="menu-auth" class="admin-menu-item   ">
                    <a href="<?= EM_URL ?>admin/auth.php" class="menu-link ">
                        <i class="fa fa-one fa-diamond"></i>正版授权
                    </a>
                </li>
            <?php endif; ?>
            <?php if (!Register::isRegLocal()) : ?>
                <li id="menu-auth" class="admin-menu-item   ">
                    <a href="<?= EM_URL ?>admin/auth.php" class="menu-link " style="color: #4C7D71; background: #EDF2F1;">
                        <i class="fa fa-one fa-diamond" style="color: #4C7D71;"></i>申请正版授权
                    </a>
                </li>
            <?php endif; ?>

            <?php endif; ?>


            <?php doAction('adm_menu') ?>
        </ul>



    </nav>


    <ul class="layui-nav top-nav pc-top-nav" lay-bar="disabled">


        <div class="" style="display: inline-block; line-height: 62px;">
                <span class="layui-breadcrumb" lay-separator=">">
                    <?= $br ?>
                </span>
        </div>
        <div style="float: right;">
            <!-- 线路选择 -->
            <li class="layui-nav-item" lay-unselect>
                <a href="javascript:;">选择线路：<?= EM_LINE[CURRENT_LINE]['name'] ?></a>
                <dl class="layui-nav-child layui-nav-child-c">
                    <?php foreach(EM_LINE as $key => $line): ?>
                    <dd><a href="javascript:;" class="line-select" data-line="<?= $key ?>"><?= $line['name'] ?></a></dd>
                    <?php endforeach; ?>
                </dl>
            </li>
            <li class="layui-nav-item" lay-unselect>
                <a href="<?= EM_URL ?>" target="_blank">网站首页</a>
            </li>
            <li class="layui-nav-item" lay-unselect>
                <a href="javascript:;">
                    <img src="<?= User::getAvatar($user_cache[UID]['avatar']) ?>" class="layui-nav-img">
                    <span><?= $user_cache[UID]['name'] ?></span>
                </a>
                <dl class="layui-nav-child layui-nav-child-c">
                    <dd><a href="<?= EM_URL ?>admin/blogger.php">个人信息</a></dd>
                    <dd><a href="javascript:;" class="delete-cache">清除缓存</a></dd>
                    <hr>
                    <dd><a href="<?= EM_URL ?>admin/account.php?action=logout">退出登录</a></dd>
                </dl>
            </li>
        </div>

    </ul>

    <menu class="nav top-nav mobile-top-nav" style="padding-left: 0; padding-right: 0;">
        <ul class="layui-nav layui-bg-gray" lay-bar="disabled" style="width: 100%; display: flex;justify-content: space-between;">
            <li class="item nav-item" id="mobile-menu-btn" style="line-height: 62px;">
                <span style="padding: 10px;"><i class="fa fa-bars" style="font-size: 20px;"></i></span>
            </li>

            <!-- 线路选择 -->
            <li class="layui-nav-item" lay-unselect>
                <a href="javascript:;">选择线路：<?= EM_LINE[CURRENT_LINE]['name'] ?></a>
                <dl class="layui-nav-child layui-nav-child-c">
                    <?php foreach(EM_LINE as $key => $line): ?>
                        <dd><a href="javascript:;" class="line-select" data-line="<?= $key ?>"><?= $line['name'] ?></a></dd>
                    <?php endforeach; ?>
                </dl>
            </li>
            <li class="layui-nav-item" lay-unselect>
                <a href="javascript:;">
                    <img src="<?= User::getAvatar($user_cache[UID]['avatar']) ?>" class="layui-nav-img">
                    <span><?= $user_cache[UID]['name'] ?></span>
                </a>

                <dl class="layui-nav-child layui-nav-child-c">
                    <dd><a href="<?= EM_URL ?>">网站首页</a></dd>
                    <dd><a href="<?= EM_URL ?>admin/blogger.php">个人信息</a></dd>
                    <dd><a href="javascript:;" class="delete-cache">清除缓存</a></dd>
                    <hr>
                    <dd><a href="<?= EM_URL ?>admin/account.php?action=logout">退出登录</a></dd>
                </dl>
            </li>


        </ul>

    </menu>

    <script>
        $('#mobile-menu-btn').click(function(){
            $('#left-menu').addClass('show');
            $('.main').addClass('show_menu');
            $('.overlay').addClass('show');
            document.body.style.overflow = 'hidden';
        })
        $('.overlay').click(function(){
            $('#left-menu').removeClass('show');
            $('.main').removeClass('show_menu');
            $('.overlay').removeClass('show');
            document.body.style.overflow = '';
        })

        // 线路选择功能
        $('.line-select').click(function(){
            var line = $(this).data('line');
            layer.load(2);
            $.ajax({
                type: "POST",
                url: "<?= EM_URL ?>admin/index.php?action=update_line",
                data: { line: line },
                dataType: "json",
                success: function (e) {
                    if(e.code == 400){
                        layer.msg(e.msg)
                    }else{
                        layer.msg('切换成功，正在刷新页面...', {
                            time: 500
                        }, function(){
                            location.reload();
                        });
                    }

                },
                error: function (xhr) {
                    layer.msg(JSON.parse(xhr.responseText).msg);
                },
                complete: function(xhr, textStatus) {
                    layer.closeAll('loading');
                }
            });

        });

        $('.delete-cache').click(function(){
            layer.load(2);
            $.ajax({
                type: "POST",
                url: "<?= EM_URL ?>admin/index.php?action=delete_cache",
                data: { type: 'cache' },
                dataType: "json",
                success: function (e) {
                    if(e.code == 400){
                        layer.msg(e.msg)
                    }else{
                        layer.msg('缓存删除成功')
                    }

                },
                error: function (xhr) {
                    layer.msg(JSON.parse(xhr.responseText).msg);
                },
                complete: function(xhr, textStatus) {
                    layer.closeAll('loading');
                }
            });
        })

    </script>




    <div id="" class="main">








        <div id="admin-content">

<div id="admin-content-body">