<?php

require_once 'globals.php';


$chargeModel = new Charge_Model();

if (empty($action)) {

    $page = Input::getIntVar('page', 1);


    $br = '<a href="./">控制台</a><a href="./order.php">订单管理</a><a><cite>充值订单</cite></a>';
    include View::getAdmView('header');
    require_once View::getAdmView('charge');
    include View::getAdmView('footer');
    View::output();
}

if($action == 'index'){
    $page = Input::getIntVar('page', 1);
    $limit = Input::getIntVar('limit');

    $res = $chargeModel->getList(null , $page, $limit);

    $list = $res['list'];
   

    output::data($list, $res['total']);
}



